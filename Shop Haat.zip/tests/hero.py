"""Homepage promo slider + image cards: assets load, controls work, text stays readable."""
import asyncio, sys
from playwright.async_api import async_playwright

IMAGES = ['slide-flash','slide-digital','slide-grocery','card-new','card-clearance','card-track']
FAILS = []
def check(ok, msg, detail=''):
    print(("  \033[32mPASS\033[0m  " if ok else "  \033[31mFAIL\033[0m  ") + msg + ('' if ok or not detail else f" — {detail}"))
    if not ok: FAILS.append(msg)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()

        print("\n\033[1m1. Promo assets\033[0m")
        pg = await b.new_page(viewport={'width':1440,'height':1000})
        for name in IMAGES:
            r = await pg.request.get(f'http://127.0.0.1:8080/assets/images/promo/{name}.jpg')
            check(r.status == 200 and 'image' in (r.headers.get('content-type') or ''),
                  f'{name}.jpg serves as an image', f'status {r.status}')

        print("\n\033[1m2. Slider markup and controls\033[0m")
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('http://127.0.0.1:8080/', wait_until='networkidle')
        check(await pg.locator('.sh-slide__img').count() == 3, 'three slides have background images')
        check(await pg.locator('.sh-sidecard__img').count() == 3, 'three promo cards have images')
        check(await pg.locator('.sh-slide__scrim').count() == 3, 'slides have a readability scrim')

        async def active():
            return await pg.evaluate("()=>[...document.querySelectorAll('.sh-slide')].findIndex(s=>s.classList.contains('sh-slide--on'))")
        await pg.click('[data-carousel-next]'); await pg.wait_for_timeout(450)
        check(await active() == 1, 'next arrow advances the slide')
        await pg.click('[data-carousel-prev]'); await pg.wait_for_timeout(450)
        check(await active() == 0, 'previous arrow goes back')
        await pg.click('.sh-carousel__dot:nth-child(3)'); await pg.wait_for_timeout(450)
        check(await active() == 2, 'pagination dot jumps to its slide')
        await pg.mouse.move(5,5)
        before = await active(); await pg.wait_for_timeout(6200)
        check(await active() != before, 'autoplay advances on its own')

        print("\n\033[1m3. Images actually render (not broken)\033[0m")
        await pg.evaluate("()=>document.querySelectorAll('.sh-slide').forEach(s=>s.classList.add('sh-slide--on'))")
        await pg.wait_for_timeout(900)
        broken = await pg.evaluate("""()=>[...document.querySelectorAll('.sh-slide__img,.sh-sidecard__img')]
            .filter(i=>!i.complete||i.naturalWidth===0).map(i=>i.src)""")
        check(not broken, 'every promo image decodes', str(broken)[:120])
        fit = await pg.evaluate("""()=>[...document.querySelectorAll('.sh-slide__img,.sh-sidecard__img')]
            .every(i=>getComputedStyle(i).objectFit==='cover')""")
        check(fit, 'all promo images use object-fit: cover')

        print("\n\033[1m4. Responsive: no overflow, text readable\033[0m")
        for w in [320, 360, 390, 414, 768, 1024, 1440, 1920]:
            pg2 = await b.new_page(viewport={'width':w,'height':1000})
            await pg2.goto('http://127.0.0.1:8080/', wait_until='networkidle')
            ov = await pg2.evaluate("()=>({sw:Math.max(document.body.scrollWidth,document.documentElement.clientWidth),cw:document.documentElement.clientWidth})")
            check(ov['sw'] <= ov['cw']+1, f'no horizontal overflow at {w}px', f"{ov['sw']}/{ov['cw']}")
            clipped = await pg2.evaluate("""()=>[...document.querySelectorAll('.sh-slide--on .sh-slide__title,.sh-sidecard__title,.sh-sidecard__text')]
                .filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent.trim().slice(0,24))""")
            check(not clipped, f'no clipped promo text at {w}px', str(clipped)[:90])
            await pg2.close()

        check(not errs, 'no JavaScript errors', str(errs[:1]))
        await b.close()

    print("\n" + "="*52)
    print(f"Hero section: \033[32m{'all checks passed' if not FAILS else str(len(FAILS)) + ' FAILED'}\033[0m")
    sys.exit(1 if FAILS else 0)

asyncio.run(main())
