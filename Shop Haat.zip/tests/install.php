<?php
/** Verifies a from-scratch installation the way a cPanel user would perform it. */
declare(strict_types=1);
$B = 'http://127.0.0.1:8099';
$J = '/tmp/inst.txt'; @unlink($J);
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }
function req(string $u, ?array $p = null, bool $follow = true): array {
    global $J;
    $ch = curl_init($u);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J, CURLOPT_COOKIEFILE => $J,
        CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_TIMEOUT => 60]);
    if ($p !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($p)); }
    $b = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $u2 = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL); curl_close($ch);
    return ['code' => $c, 'body' => (string)$b, 'url' => $u2];
}
function tok(string $b): string { return preg_match('/name="csrf_token" value="([^"]+)"/', $b, $m) ? $m[1] : ''; }

echo "\n\033[1m1. Uninstalled site redirects to the installer\033[0m\n";
$r = req("$B/index.php");
check(str_contains($r['url'], 'install'), 'visiting the site opens the installer', $r['url']);
check(stripos($r['body'], 'Fatal error') === false, 'no fatal error on an unconfigured site');

echo "\n\033[1m2. Bad DB credentials give a clear message, not a 500\033[0m\n";
$good = ['db_host' => 'localhost', 'db_name' => 'freshdb', 'db_user' => 'shopuser', 'db_pass' => 'shoppass123',
    'site_name' => 'FreshMart', 'admin_email' => 'fresh@shop.test',
    'admin_password' => 'FreshPass123', 'admin_password2' => 'FreshPass123', 'demo_data' => '1'];
$r = req("$B/install/index.php");
$t = tok($r['body']);
$r = req("$B/install/index.php", array_merge($good, ['csrf_token' => $t, 'db_pass' => 'WRONGPASSWORD']));
check($r['code'] === 200, 'bad credentials still return HTTP 200', "got {$r['code']}");
check(stripos($r['body'], 'Fatal error') === false && stripos($r['body'], 'PDOException') === false,
    'no stack trace or raw PDO exception shown');
check(!str_contains($r['body'], 'WRONGPASSWORD'), 'the submitted password is not echoed back into the HTML');
check((bool)preg_match('/could not|unable|denied|failed|check/i', strip_tags($r['body'])), 'a human-readable DB error is shown');

echo "\n\033[1m3. Real installation\033[0m\n";
$r = req("$B/install/index.php");
$t = tok($r['body']);
$r = req("$B/install/index.php", array_merge($good, ['csrf_token' => $t]));
check(stripos($r['body'], 'Fatal error') === false, 'installation ran without fatal errors');
check(is_file('/home/user/fresh/config/database.php'), 'config/database.php was written automatically');
check(is_file('/home/user/fresh/config/installed.lock'), 'install lock file created');

$pdo = new PDO('mysql:host=127.0.0.1;dbname=freshdb;charset=utf8mb4', 'shopuser', 'shoppass123');
$tables = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='freshdb'")->fetchColumn();
check($tables >= 22, "all tables created ($tables)");
$fks = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.table_constraints WHERE table_schema='freshdb' AND constraint_type='FOREIGN KEY'")->fetchColumn();
check($fks >= 20, "foreign keys created ($fks)");
$admins = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
check($admins >= 1, 'admin account created');
$h = (string)$pdo->query("SELECT password_hash FROM admins WHERE email='fresh@shop.test'")->fetchColumn();
check(str_starts_with($h, '$2y$') || str_starts_with($h, '$argon'), 'admin password is hashed');
check(password_verify('FreshPass123', $h), 'the chosen admin password actually works');

echo "\n\033[1m4. Config file safety\033[0m\n";
$cfg = (string)file_get_contents('/home/user/fresh/config/database.php');
check(str_contains($cfg, 'shoppass123'), 'the DB password is stored in the config file (expected)');
$r = req("$B/config/database.php");
check(!str_contains($r['body'], 'shoppass123'), 'requesting config/database.php over HTTP does not reveal the password');

echo "\n\033[1m5. Installed site works and the installer locks itself\033[0m\n";
$r = req("$B/index.php");
check($r['code'] === 200 && !str_contains($r['url'], 'install'), 'homepage now loads normally');
check(str_contains($r['body'], 'FreshMart'), 'the site name chosen during install is applied');
// Correct behaviour is either a redirect away from the installer, or a clear "already installed" notice.
$r = req("$B/install/index.php");
$redirected = !str_contains($r['url'], 'install');
$notice = (bool)preg_match('/already installed|locked|remove/i', strip_tags($r['body']));
check($redirected || $notice, 'the installer refuses to run a second time',
    'still serving the install form at ' . $r['url']);
check(!str_contains($r['body'], 'name="db_pass"'), 'the install form is no longer reachable');
$before = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
$r = req("$B/install/index.php");
$t2 = tok($r['body']);
req("$B/install/index.php", array_merge($good, ['csrf_token' => $t2,
    'admin_email' => 'hack@x.test', 'site_name' => 'Hacked', 'demo_data' => '0']));
$after = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
check($after === $before, 'a replayed install request cannot create another admin');

echo "\n\033[1m6. Fresh admin can sign in\033[0m\n";
$r = req("$B/admin/login.php");
$r = req("$B/admin/login.php", ['csrf_token' => tok($r['body']), 'email' => 'fresh@shop.test', 'password' => 'FreshPass123']);
check(str_contains($r['body'], 'sh-admin-sidebar'), 'newly created admin can sign in');

echo "\n" . str_repeat('=', 50) . "\n";
echo "Install: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
