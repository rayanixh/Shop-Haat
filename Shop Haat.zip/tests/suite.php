<?php
/**
 * ShopHaat integration test suite.
 * Drives the real application over HTTP with a cookie jar, exactly like a browser.
 */
declare(strict_types=1);

$BASE = rtrim($argv[1] ?? 'http://127.0.0.1:8080', '/');
$JAR  = '/tmp/sh-cookies.txt';
$ADMIN_JAR = '/tmp/sh-admin-cookies.txt';

$DB = ['host' => '127.0.0.1', 'name' => 'shopdb', 'user' => 'shopuser', 'pass' => 'shoppass123'];
$ADMIN_EMAIL = 'admin@shophaat.test';
$ADMIN_PASS  = 'AdminPass123';
$CUST_EMAIL  = 'customer' . substr((string)time(), -5) . '@example.com';
$CUST_PASS   = 'Customer123';

$pass = 0; $fail = 0; $failures = [];

function c(string $t): string { return $t; }
function ok(string $name): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $name\n"; }
function bad(string $name, string $why = ''): void {
    global $fail, $failures; $fail++; $failures[] = $name . ($why ? " — $why" : '');
    echo "  \033[31mFAIL\033[0m  $name" . ($why ? " — $why" : '') . "\n";
}
function check(string $name, bool $cond, string $why = ''): bool {
    if ($cond) { ok($name); return true; }
    bad($name, $why); return false;
}
function section(string $t): void { echo "\n\033[1m$t\033[0m\n"; }

/** HTTP client with cookie jar. */
function http(string $method, string $url, array $data = [], string $jar = '/tmp/sh-cookies.txt', bool $follow = true): array
{
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEJAR      => $jar,
        CURLOPT_COOKIEFILE     => $jar,
        CURLOPT_FOLLOWLOCATION => $follow,
        CURLOPT_MAXREDIRS      => 6,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HEADER         => true,
    ];
    if ($method === 'POST') {
        $opts[CURLOPT_POST] = true;
        $opts[CURLOPT_POSTFIELDS] = $data;
    }
    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hlen = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) { return ['code' => 0, 'body' => '', 'headers' => '', 'url' => $url, 'error' => $err]; }
    return [
        'code' => $code,
        'headers' => substr((string)$raw, 0, $hlen),
        'body' => substr((string)$raw, $hlen),
        'url' => $final,
        'error' => '',
    ];
}

function csrf(string $html): string
{
    if (preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/', $html, $m)) { return $m[1]; }
    if (preg_match('/SH_CSRF\s*=\s*"([a-f0-9]+)"/', $html, $m)) { return $m[1]; }
    return '';
}

function db(): PDO {
    global $DB;
    return new PDO("mysql:host={$DB['host']};dbname={$DB['name']};charset=utf8mb4", $DB['user'], $DB['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
}

$ROOT = '/home/user/shop';
@unlink($JAR); @unlink($ADMIN_JAR);

echo "\n\033[1;36m═══ ShopHaat integration suite ═══\033[0m\nTarget: $BASE\n";

// ---------------------------------------------------------------------------
section('TEST A — fresh install: no config must redirect to the installer');
@unlink($ROOT . '/config/database.php');
@unlink($ROOT . '/config/installed.lock');
$r = http('GET', $BASE . '/index.php');
check('A1 homepage redirects to installer', strpos($r['url'], '/install/') !== false, 'landed on ' . $r['url']);
check('A2 installer renders (HTTP 200)', $r['code'] === 200, 'code ' . $r['code']);
check('A3 no blank page', strlen(trim($r['body'])) > 500);
check('A4 installer shows requirement checks', strpos($r['body'], 'Server requirements') !== false);
check('A5 no PHP notice/fatal leaked', stripos($r['body'], 'Fatal error') === false && stripos($r['body'], 'Warning:') === false);

// ---------------------------------------------------------------------------
section('TEST C — invalid database credentials must give a clean error');
$tok = csrf($r['body']);
$rc = http('POST', $BASE . '/install/index.php', [
    'csrf_token' => $tok, 'db_host' => $DB['host'], 'db_name' => $DB['name'],
    'db_user' => $DB['user'], 'db_pass' => 'definitely-wrong-password',
    'site_name' => 'ShopHaat', 'admin_email' => $ADMIN_EMAIL,
    'admin_password' => $ADMIN_PASS, 'admin_password2' => $ADMIN_PASS, 'demo_data' => '1',
]);
check('C1 responds 200 (not a 500)', $rc['code'] === 200, 'code ' . $rc['code']);
check('C2 shows a friendly connection error', stripos($rc['body'], 'Could not connect to the database') !== false);
check('C3 password not echoed back to the page', strpos($rc['body'], 'definitely-wrong-password') === false);
check('C4 no stack trace exposed', stripos($rc['body'], '#0 ') === false && stripos($rc['body'], 'PDOException') === false);

section('TEST — installer input validation');
$tok = csrf($rc['body']);
$rv = http('POST', $BASE . '/install/index.php', [
    'csrf_token' => $tok, 'db_host' => $DB['host'], 'db_name' => $DB['name'],
    'db_user' => $DB['user'], 'db_pass' => $DB['pass'],
    'site_name' => 'ShopHaat', 'admin_email' => 'not-an-email',
    'admin_password' => 'short', 'admin_password2' => 'different', 'demo_data' => '1',
]);
check('V1 rejects invalid email', stripos($rv['body'], 'valid email') !== false);
check('V2 rejects weak password', stripos($rv['body'], 'at least 8 characters') !== false);
check('V3 rejects mismatched confirmation', stripos($rv['body'], 'does not match') !== false);

// ---------------------------------------------------------------------------
section('TEST — real installation');
try {
    $p = new PDO("mysql:host={$DB['host']};charset=utf8mb4", $DB['user'], $DB['pass']);
    $p->exec("DROP DATABASE IF EXISTS `{$DB['name']}`");
    $p->exec("CREATE DATABASE `{$DB['name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch (Throwable $e) { bad('DB reset', $e->getMessage()); }

$tok = csrf($rv['body']);
$ri = http('POST', $BASE . '/install/index.php', [
    'csrf_token' => $tok, 'db_host' => $DB['host'], 'db_name' => $DB['name'],
    'db_user' => $DB['user'], 'db_pass' => $DB['pass'],
    'site_name' => 'ShopHaat', 'admin_email' => $ADMIN_EMAIL,
    'admin_password' => $ADMIN_PASS, 'admin_password2' => $ADMIN_PASS, 'demo_data' => '1',
]);
check('I1 installation completes', stripos($ri['body'], 'Installation complete') !== false || stripos($ri['body'], 'Setup finished') !== false,
    substr(strip_tags($ri['body']), 0, 300));
check('I2 config/database.php written', is_file($ROOT . '/config/database.php'));
check('I3 installation lock created', is_file($ROOT . '/config/installed.lock'));

$expected = ['users','admins','categories','brands','products','product_images','cart','cart_items','orders',
    'order_items','payments','payment_methods','payment_gateways','product_codes','reviews','wishlist',
    'coupons','addresses','settings','notifications','notification_logs','app_logs'];
try {
    $have = array_column(db()->query('SHOW TABLES')->fetchAll(PDO::FETCH_NUM), 0);
    $missing = array_diff($expected, $have);
    check('I4 all ' . count($expected) . ' tables exist', $missing === [], 'missing: ' . implode(',', $missing));
    $fk = (int)db()->query("SELECT COUNT(*) FROM information_schema.table_constraints
        WHERE constraint_schema='{$DB['name']}' AND constraint_type='FOREIGN KEY'")->fetchColumn();
    check('I5 foreign keys created (' . $fk . ')', $fk >= 15);
    $idx = (int)db()->query("SELECT COUNT(DISTINCT table_name, index_name) FROM information_schema.statistics
        WHERE table_schema='{$DB['name']}'")->fetchColumn();
    check('I6 indexes created (' . $idx . ')', $idx >= 40);
    $np = (int)db()->query('SELECT COUNT(*) FROM products')->fetchColumn();
    check('I7 starter catalogue seeded (' . $np . ' products)', $np >= 25);
    $adm = (int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn();
    check('I8 admin account created', $adm === 1);
    $hash = (string)db()->query('SELECT password_hash FROM admins LIMIT 1')->fetchColumn();
    check('I9 admin password is hashed', password_verify($ADMIN_PASS, $hash) && $hash !== $ADMIN_PASS);
    $pm = (int)db()->query('SELECT COUNT(*) FROM payment_methods')->fetchColumn();
    check('I10 payment methods seeded', $pm >= 4);
    $nt = (int)db()->query('SELECT COUNT(*) FROM notifications')->fetchColumn();
    check('I11 notification matrix seeded (' . $nt . ')', $nt === 32);
} catch (Throwable $e) { bad('schema verification', $e->getMessage()); }

// ---------------------------------------------------------------------------
section('TEST B / E — installed site opens the homepage, never the installer');
$r = http('GET', $BASE . '/index.php');
check('B1 homepage loads 200', $r['code'] === 200, 'code ' . $r['code']);
check('B2 does NOT redirect to installer', strpos($r['url'], '/install/') === false, $r['url']);
check('B3 marketplace content present', strpos($r['body'], 'Flash Sale') !== false && strpos($r['body'], 'sh-product-card') !== false);
$r2 = http('GET', $BASE . '/index.php');
check('E1 refresh still shows homepage', strpos($r2['url'], '/install/') === false && $r2['code'] === 200);
$ri2 = http('GET', $BASE . '/install/index.php');
check('E2 visiting installer redirects to homepage', strpos($ri2['url'], '/install/') === false, $ri2['url']);

section('TEST D — config present but tables missing');
try { db()->exec('DROP TABLE IF EXISTS notification_logs'); } catch (Throwable $e) {}
// products/orders etc. still exist; drop a required one to trigger repair
try { db()->exec('SET FOREIGN_KEY_CHECKS=0; '); } catch (Throwable $e) {}
$rd = http('GET', $BASE . '/index.php');
check('D1 no HTTP 500 with a damaged schema', $rd['code'] === 200, 'code ' . $rd['code']);
// restore
$tok = csrf(http('GET', $BASE . '/install/index.php?step=repair')['body']);
http('POST', $BASE . '/install/index.php?step=repair', [
    'csrf_token' => $tok, 'db_host' => $DB['host'], 'db_name' => $DB['name'],
    'db_user' => $DB['user'], 'db_pass' => $DB['pass'], 'site_name' => 'ShopHaat',
    'admin_email' => $ADMIN_EMAIL, 'admin_password' => $ADMIN_PASS,
    'admin_password2' => $ADMIN_PASS, 'demo_data' => '0',
]);
$tables = array_column(db()->query('SHOW TABLES')->fetchAll(PDO::FETCH_NUM), 0);
check('D2 re-running installer repairs missing tables', in_array('notification_logs', $tables, true));

echo "\n\033[1mResults so far: \033[32m$pass passed\033[0m, \033[31m$fail failed\033[0m\n";
if ($failures) { echo "Failures:\n - " . implode("\n - ", $failures) . "\n"; }

// Save state for the next phase
file_put_contents('/tmp/sh-test-state.json', json_encode([
    'pass' => $pass, 'fail' => $fail, 'failures' => $failures,
    'admin_email' => $ADMIN_EMAIL, 'admin_pass' => $ADMIN_PASS,
    'cust_email' => $CUST_EMAIL, 'cust_pass' => $CUST_PASS,
]));

exit($fail > 0 ? 1 : 0);
