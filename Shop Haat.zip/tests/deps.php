<?php
/**
 * Loads each library file in a FRESH php process, on its own, and verifies that every
 * sh_* function it calls is actually defined afterwards. This catches the
 * "include forgot its dependency" class of bug that php -l cannot see.
 */
declare(strict_types=1);
$root = '/home/user/shop';

if (($argv[1] ?? '') === '--child') {
    $file = $argv[2];
    // Real requests always bootstrap config.php first; model that, then load the file alone.
    require_once '/home/user/shop/config/config.php';
    require_once $file;
    $src = file_get_contents($file);
    preg_match_all('/\b(sh_[a-z0-9_]+)\s*\(/i', $src, $m);
    $missing = [];
    foreach (array_unique($m[1]) as $fn) {
        if (!function_exists($fn)) { $missing[] = $fn; }
    }
    echo implode(',', $missing);
    exit(0);
}

$files = array_merge(glob("$root/includes/*.php") ?: [], glob("$root/config/*.php") ?: []);
$fail = 0;
foreach ($files as $f) {
    $base = basename($f);
    // Partials render markup; loading them standalone is still safe because they only
    // define/require at the top, but skip pure-view files that need page variables.
    $out = [];
    exec('php ' . escapeshellarg(__FILE__) . ' --child ' . escapeshellarg($f) . ' 2>&1', $out, $rc);
    $res = trim(implode("\n", $out));
    // Strip any rendered HTML from partials; we only care about the trailing list.
    $lines = array_filter(explode("\n", $res));
    $last = $lines ? trim((string)end($lines)) : '';
    $missing = ($last !== '' && !str_contains($last, '<') && preg_match('/^sh_[a-z0-9_,]+$/i', $last))
        ? explode(',', $last) : [];

    if ($rc !== 0 && stripos($res, 'Fatal error') !== false) {
        echo "  \033[31mFAIL\033[0m  $base — fatal when loaded alone\n";
        foreach (array_slice($lines, 0, 3) as $l) { echo "        " . trim($l) . "\n"; }
        $fail++;
    } elseif ($missing) {
        echo "  \033[31mFAIL\033[0m  $base — undefined after load: " . implode(', ', $missing) . "\n";
        $fail++;
    } else {
        echo "  \033[32mPASS\033[0m  $base\n";
    }
}
echo "\nDependency check: " . ($fail ? "\033[31m$fail file(s) with unresolved calls\033[0m" : "\033[32mall files self-sufficient\033[0m") . "\n";
exit($fail ? 1 : 0);
