import sys, asyncio
from playwright.async_api import async_playwright

async def main():
    url = sys.argv[1]; out = sys.argv[2]
    w = int(sys.argv[3]) if len(sys.argv)>3 else 1440
    h = int(sys.argv[4]) if len(sys.argv)>4 else 1100
    full = len(sys.argv)>5 and sys.argv[5]=='full'
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width':w,'height':h})
        errs=[]
        pg.on('console', lambda m: errs.append(m.text) if m.type=='error' else None)
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(url, wait_until='networkidle', timeout=45000)
        await pg.wait_for_timeout(700)
        # horizontal overflow check
        ov = await pg.evaluate("() => ({sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth})")
        await pg.screenshot(path=out, full_page=full)
        await b.close()
        print(f"OVERFLOW scrollW={ov['sw']} clientW={ov['cw']} " + ("*** HORIZONTAL OVERFLOW ***" if ov['sw']>ov['cw']+1 else "ok"))
        if errs: print("JS ERRORS:", errs[:5])
        else: print("JS: clean")
asyncio.run(main())
