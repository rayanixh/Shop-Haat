<?php
/** Quick page-by-page smoke test: every public page must return 200 and clean HTML. */
declare(strict_types=1);
$BASE = rtrim($argv[1] ?? 'http://127.0.0.1:8080', '/');
$JAR = '/tmp/sh-smoke.txt';
@unlink($JAR);

function get(string $url, string $jar): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar,
        CURLOPT_COOKIEFILE => $jar, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 25]);
    $b = curl_exec($ch);
    $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $c, 'body' => (string)$b];
}

$slug = null; $catSlug = null;
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123');
    $slug = $pdo->query('SELECT slug FROM products WHERE status=1 LIMIT 1')->fetchColumn();
    $catSlug = $pdo->query('SELECT slug FROM categories LIMIT 1')->fetchColumn();
} catch (Throwable $e) { echo "DB: {$e->getMessage()}\n"; }

$pages = [
    'index.php', 'products.php', 'products.php?flash=1', 'products.php?sort=newest',
    'products.php?q=wireless', 'products.php?discount=20&in_stock=1&sort=price_asc',
    'products.php?min_price=500&max_price=2000&rating=4',
    'category.php?slug=' . urlencode((string)$catSlug),
    'product.php?slug=' . urlencode((string)$slug),
    'cart.php', 'login.php', 'register.php', 'track.php', 'support.php', 'help.php',
    'page.php?p=about', 'page.php?p=terms', 'page.php?p=privacy', 'page.php?p=returns', 'page.php?p=shipping',
    'admin/login.php',
    // Expected redirects / 404s
    'checkout.php', 'account.php', 'orders.php', 'wishlist.php', 'addresses.php', 'digital.php', 'password.php',
    'product.php?slug=does-not-exist-xyz', 'category.php?slug=nope-xyz', 'page.php?p=nope',
    'order-details.php?id=999999', 'payment.php?id=999999', 'order-success.php?id=999999',
];

$fail = 0; $pass = 0;
foreach ($pages as $p) {
    $r = get($BASE . '/' . $p, $JAR);
    $body = $r['body'];
    $expect404 = str_contains($p, 'does-not-exist') || str_contains($p, 'nope') || str_contains($p, '999999');
    $okCode = $expect404 ? in_array($r['code'], [200, 404], true) : $r['code'] === 200;
    $leak = stripos($body, 'Fatal error') !== false
        || stripos($body, 'Parse error') !== false
        || preg_match('/\bWarning<\/b>:/i', $body)
        || stripos($body, 'Uncaught') !== false
        || stripos($body, 'PDOException') !== false
        || stripos($body, 'shoppass123') !== false;
    $hasBody = strlen(trim(strip_tags($body))) > 40;

    if ($okCode && !$leak && $hasBody) { $pass++; echo "  \033[32mPASS\033[0m  $p ({$r['code']})\n"; }
    else {
        $fail++;
        $why = !$okCode ? "code {$r['code']}" : ($leak ? 'error leaked in output' : 'empty body');
        echo "  \033[31mFAIL\033[0m  $p — $why\n";
        if ($leak) {
            if (preg_match('/(Fatal error|Warning|Uncaught|Parse error)[^<\n]{0,200}/i', $body, $m)) { echo "         " . trim($m[0]) . "\n"; }
        }
    }
}
echo "\nSmoke: \033[32m$pass passed\033[0m, \033[31m$fail failed\033[0m\n";
exit($fail > 0 ? 1 : 0);
