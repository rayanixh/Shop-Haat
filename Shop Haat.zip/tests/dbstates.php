<?php
/**
 * Verifies the installer/database gating rules:
 *   healthy DB      -> installer refused, store serves normally
 *   DB missing      -> installer opens (repair) with an explanation
 *   tables missing  -> installer opens (repair) with an explanation
 *   server down     -> 503 with a recovery link, never a redirect loop
 *
 * Run with MariaDB up. It drops and recreates `shopdb`, so use a test database only.
 */
declare(strict_types=1);
$B = 'http://127.0.0.1:8080';
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

function head(string $url): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 25]);
    $b = curl_exec($ch);
    $r = ['code' => (int)curl_getinfo($ch, CURLINFO_HTTP_CODE),
          'loc' => (string)curl_getinfo($ch, CURLINFO_REDIRECT_URL), 'body' => (string)$b];
    curl_close($ch);
    return $r;
}
function get(string $url): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 25]);
    $b = curl_exec($ch);
    $r = ['code' => (int)curl_getinfo($ch, CURLINFO_HTTP_CODE),
          'url' => (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL), 'body' => (string)$b];
    curl_close($ch);
    return $r;
}
function root(): PDO {
    return new PDO('mysql:host=127.0.0.1;charset=utf8mb4', 'shopuser', 'shoppass123',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
}
function schema_ok(): bool {
    try { return (int)root()->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='shopdb'")->fetchColumn() >= 22; }
    catch (Throwable $e) { return false; }
}
function reinstall(string $B): bool {
    // Already healthy? The installer will (correctly) refuse, which counts as success.
    if (schema_ok()) { return true; }
    $J = '/tmp/dbst.txt'; @unlink($J);
    $ch = curl_init("$B/install/index.php?step=repair");
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J, CURLOPT_COOKIEFILE => $J, CURLOPT_TIMEOUT => 60]);
    $f = (string)curl_exec($ch); curl_close($ch);
    if (!preg_match('/name="csrf_token" value="([^"]+)"/', $f, $m)) { return false; }
    $ch = curl_init("$B/install/index.php?step=repair");
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J, CURLOPT_COOKIEFILE => $J,
        CURLOPT_TIMEOUT => 120, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'csrf_token' => $m[1], 'db_host' => 'localhost', 'db_name' => 'shopdb',
            'db_user' => 'shopuser', 'db_pass' => 'shoppass123', 'site_name' => 'ShopHaat',
            'admin_email' => 'admin@shophaat.test', 'admin_password' => 'AdminPass123',
            'admin_password2' => 'AdminPass123', 'demo_data' => '1'])]);
    curl_exec($ch); curl_close($ch);
    return schema_ok();
}

echo "\n\033[1m1. Healthy database — installer must stay shut\033[0m\n";
if (!reinstall($B)) { bad('could not prepare a healthy install'); }
$r = head("$B/");
check($r['code'] === 200, 'storefront serves normally', "code {$r['code']}");
foreach (['install/index.php', 'install/index.php?step=repair', 'install/index.php?step=repair&reason=database'] as $u) {
    $r = head("$B/$u");
    check($r['code'] === 302 && str_contains($r['loc'], 'index.php') && !str_contains($r['loc'], 'install'),
        "/$u redirects away from the installer", "code {$r['code']} loc {$r['loc']}");
}
$r = get("$B/install/index.php");
check(!str_contains($r['body'], 'name="db_pass"'), 'install form is not rendered on a healthy store');

$before = (int)root()->query('SELECT COUNT(*) FROM shopdb.admins')->fetchColumn();
$ch = curl_init("$B/install/index.php?step=repair");
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query(['db_host' => 'localhost', 'db_name' => 'shopdb', 'db_user' => 'shopuser',
        'db_pass' => 'shoppass123', 'site_name' => 'Hacked', 'admin_email' => 'hack@x.test',
        'admin_password' => 'HackPass123', 'admin_password2' => 'HackPass123', 'demo_data' => '0'])]);
curl_exec($ch); curl_close($ch);
$after = (int)root()->query('SELECT COUNT(*) FROM shopdb.admins')->fetchColumn();
check($after === $before, 'a forced install POST cannot alter a healthy store');
check((string)root()->query("SELECT setting_value FROM shopdb.settings WHERE setting_key='site_name'")->fetchColumn() === 'ShopHaat',
    'site name was not overwritten by the forced POST');

echo "\n\033[1m2. Database deleted — installer must open\033[0m\n";
root()->exec('DROP DATABASE IF EXISTS shopdb');
$r = head("$B/");
check($r['code'] === 302 && str_contains($r['loc'], 'install'), 'homepage redirects to the installer', "code {$r['code']}");
check(str_contains($r['loc'], 'reason=database'), 'redirect states the reason is the missing database', $r['loc']);
$r = get("$B/");
check($r['code'] === 200 && str_contains($r['body'], 'name="db_pass"'), 'the install form is shown');
check(!str_contains($r['body'], 'Database unavailable'), 'no dead-end 503 is shown');
// The explanatory banner was removed at the user's request: the installer must open silently.
check(!str_contains($r['body'], 'Setup needs your attention'), 'no setup notice banner is shown');
check((bool)preg_match('/name="db_name"[^>]*value="shopdb"/', $r['body']), 'database name is pre-filled from the saved config');
check(!preg_match('/name="db_pass"[^>]*value="[^"]+"/', $r['body']), 'the saved password is NOT pre-filled into the HTML');
check(!str_contains($r['body'], 'shoppass123'), 'no credential appears anywhere in the page');

echo "\n\033[1m3. Recovery through the installer\033[0m\n";
check(reinstall($B), 'the store reinstalls itself from the web form');
$r = head("$B/");
check($r['code'] === 200, 'storefront works again');
$r = head("$B/install/index.php?step=repair");
check($r['code'] === 302, 'installer locks itself again afterwards');

echo "\n\033[1m4. Tables dropped — installer must open in repair mode\033[0m\n";
root()->exec('DROP DATABASE IF EXISTS shopdb');
root()->exec('CREATE DATABASE shopdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
$r = head("$B/");
check($r['code'] === 302 && str_contains($r['loc'], 'reason=tables'), 'redirects with reason=tables', $r['loc']);
$r = get("$B/");
check(!str_contains($r['body'], 'Setup needs your attention'), 'no setup notice banner in repair mode');
check(reinstall($B), 'repair recreates the schema');
check(head("$B/")['code'] === 200, 'storefront healthy after repair');

echo "\n" . str_repeat('=', 52) . "\n";
echo "DB states: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
echo "(Server-down handling is covered separately: stopping MariaDB yields a 503 with a recovery link.)\n";
exit($fail ? 1 : 0);
