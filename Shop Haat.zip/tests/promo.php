<?php
/**
 * Admin homepage-image manager.
 *
 * Proves the frontend is driven by the database (not hard-coded), and that every
 * admin action — upload, edit, add, reorder, hide, delete — reaches the homepage.
 */
declare(strict_types=1);
$B = 'http://127.0.0.1:8080';
$ROOT = '/home/user/shop';
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

$J = '/tmp/promo-adm.txt'; @unlink($J);
function req(string $url, $post = null, bool $follow = true): string {
    global $J;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J,
        CURLOPT_COOKIEFILE => $J, CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_TIMEOUT => 60]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
    $b = (string)curl_exec($ch); curl_close($ch);
    return $b;
}
function tok(string $h): string { return preg_match('/name="csrf_token" value="([^"]+)"/', $h, $m) ? $m[1] : ''; }
function home(): string { return (string)file_get_contents('http://127.0.0.1:8080/'); }

function makePng(string $path, int $w = 900, int $h = 340): void {
    $chunk = static fn(string $t, string $d): string => pack('N', strlen($d)) . $t . $d . pack('N', crc32($t . $d));
    $raw = '';
    for ($y = 0; $y < $h; $y++) { $raw .= "\x00" . str_repeat("\x14\xB4\x78", $w); }
    file_put_contents($path, "\x89PNG\r\n\x1a\n"
        . $chunk('IHDR', pack('NNCCCCC', $w, $h, 8, 2, 0, 0, 0))
        . $chunk('IDAT', gzcompress($raw)) . $chunk('IEND', ''));
}
$png = '/tmp/promo-test.png';
makePng($png);

// Snapshot so the suite leaves no trace.
$snapshot = $pdo->query('SELECT * FROM promo_slides ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$restore = function () use ($pdo, $snapshot, $ROOT) {
    $pdo->exec('DELETE FROM promo_slides');
    $st = $pdo->prepare('INSERT INTO promo_slides
        (id,placement,slot,tag,title,subtitle,button_text,button_url,image,overlay,sort_order,status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    foreach ($snapshot as $r) {
        $st->execute([$r['id'], $r['placement'], $r['slot'], $r['tag'], $r['title'], $r['subtitle'],
            $r['button_text'], $r['button_url'], $r['image'], $r['overlay'], $r['sort_order'], $r['status']]);
    }
    foreach (glob($ROOT . '/uploads/promo/*') ?: [] as $f) { @unlink($f); }
};

$p = req("$B/admin/login.php");
req("$B/admin/login.php", http_build_query(['csrf_token' => tok($p),
    'email' => 'admin@shophaat.test', 'password' => 'AdminPass123']));
$form = req("$B/admin/homepage.php");
check(str_contains($form, 'Slider slides'), 'admin homepage manager loads');
check(str_contains($form, 'Feature cards'), 'feature cards section is present');

echo "\n\033[1m1. Frontend reads from the database, not the code\033[0m\n";
$src = (string)file_get_contents($ROOT . '/index.php');
check(!str_contains($src, 'assets/images/promo/'), 'index.php contains no hard-coded promo image paths');
check(str_contains($src, 'sh_promo_items('), 'index.php loads promo content via sh_promo_items()');
$rows = (int)$pdo->query('SELECT COUNT(*) FROM promo_slides')->fetchColumn();
check($rows >= 6, "promo_slides table is populated ($rows rows)");

echo "\n\033[1m2. Uploading an image updates the homepage\033[0m\n";
$id = (int)$pdo->query("SELECT id FROM promo_slides WHERE placement='slider' ORDER BY sort_order LIMIT 1")->fetchColumn();
$edit = req("$B/admin/homepage.php?edit=$id");
$marker = 'DBDriven' . time();
req("$B/admin/homepage.php?edit=$id", [
    'csrf_token' => tok($edit), 'form' => 'save', 'id' => (string)$id, 'placement' => 'slider',
    'tag' => 'Live Badge', 'title' => $marker . ' headline', 'subtitle' => 'Copy from the database.',
    'button_text' => 'Shop Now', 'button_url' => 'products.php?sort=popular',
    'overlay' => '55', 'status' => '1',
    'image' => new CURLFile($png, 'image/png', 'slide.png'),
]);
$stored = (string)$pdo->query("SELECT COALESCE(image,'') FROM promo_slides WHERE id=$id")->fetchColumn();
check($stored !== '' && !str_starts_with($stored, 'promo/'), 'the uploaded filename is stored in the DB', $stored);
check(is_file($ROOT . '/uploads/promo/' . $stored), 'the file is written to uploads/promo/');

$h = home();
check(str_contains($h, 'uploads/promo/' . $stored), 'the new image appears on the homepage');
check(str_contains($h, $marker . ' headline'), 'the new title appears on the homepage');
check(str_contains($h, 'Live Badge'), 'the new badge appears on the homepage');
check(str_contains($h, 'opacity:0.55'), 'the overlay strength is applied');
check(!str_contains($h, 'slide-flash.jpg'), 'the old default image is no longer used');

echo "\n\033[1m3. Adding, hiding and reordering slides\033[0m\n";
$before = (int)$pdo->query("SELECT COUNT(*) FROM promo_slides WHERE placement='slider'")->fetchColumn();
$newForm = req("$B/admin/homepage.php?new=slider");
$addMark = 'Added' . time();
req("$B/admin/homepage.php", [
    'csrf_token' => tok($newForm), 'form' => 'save', 'id' => '0', 'placement' => 'slider',
    'title' => $addMark, 'subtitle' => 'extra slide', 'button_text' => 'Go', 'button_url' => 'products.php',
    'overlay' => '70', 'status' => '1', 'image' => new CURLFile($png, 'image/png', 'extra.png'),
]);
$after = (int)$pdo->query("SELECT COUNT(*) FROM promo_slides WHERE placement='slider'")->fetchColumn();
check($after === $before + 1, 'a new slide was created');
check(str_contains(home(), $addMark), 'the new slide shows on the homepage');

$newId = (int)$pdo->query("SELECT id FROM promo_slides WHERE title=" . $pdo->quote($addMark))->fetchColumn();
$t = tok(req("$B/admin/homepage.php"));
req("$B/admin/homepage.php", http_build_query(['csrf_token' => $t, 'form' => 'toggle', 'id' => $newId]));
check((int)$pdo->query("SELECT status FROM promo_slides WHERE id=$newId")->fetchColumn() === 0, 'slide switched to hidden');
check(!str_contains(home(), $addMark), 'a hidden slide is removed from the homepage');

$ordBefore = $pdo->query("SELECT id FROM promo_slides WHERE placement='slider' ORDER BY sort_order")->fetchAll(PDO::FETCH_COLUMN);
$second = (int)($ordBefore[1] ?? 0);
if ($second > 0) {
    req("$B/admin/homepage.php", http_build_query(['csrf_token' => $t, 'form' => 'move', 'id' => $second, 'dir' => 'up']));
    $ordAfter = $pdo->query("SELECT id FROM promo_slides WHERE placement='slider' ORDER BY sort_order")->fetchAll(PDO::FETCH_COLUMN);
    check((int)$ordAfter[0] === $second, 'moving a slide up reorders it', implode(',', $ordAfter));
}

echo "\n\033[1m4. Deleting removes the row and the file\033[0m\n";
$delImg = (string)$pdo->query("SELECT COALESCE(image,'') FROM promo_slides WHERE id=$newId")->fetchColumn();
$t = tok(req("$B/admin/homepage.php"));
req("$B/admin/homepage.php", http_build_query(['csrf_token' => $t, 'form' => 'delete', 'id' => $newId]));
check((int)$pdo->query("SELECT COUNT(*) FROM promo_slides WHERE id=$newId")->fetchColumn() === 0, 'the slide row is deleted');
check($delImg === '' || !is_file($ROOT . '/uploads/promo/' . $delImg), 'its uploaded file is cleaned up');

$cardId = (int)$pdo->query("SELECT id FROM promo_slides WHERE placement='card' LIMIT 1")->fetchColumn();
$t = tok(req("$B/admin/homepage.php"));
$resp = req("$B/admin/homepage.php", http_build_query(['csrf_token' => $t, 'form' => 'delete', 'id' => $cardId]));
check((int)$pdo->query("SELECT COUNT(*) FROM promo_slides WHERE id=$cardId")->fetchColumn() === 1,
    'the three feature cards cannot be deleted');

echo "\n\033[1m5. Validation and safety\033[0m\n";
$bad = '/tmp/promo-fake.png';
file_put_contents($bad, '<?php echo "x"; ?>');
$imgBefore = (string)$pdo->query("SELECT COALESCE(image,'') FROM promo_slides WHERE id=$cardId")->fetchColumn();
$edit = req("$B/admin/homepage.php?edit=$cardId");
$resp = req("$B/admin/homepage.php?edit=$cardId", [
    'csrf_token' => tok($edit), 'form' => 'save', 'id' => (string)$cardId,
    'title' => 'Card', 'overlay' => '70', 'status' => '1',
    'image' => new CURLFile($bad, 'image/png', 'x.png'),
], false);
check((bool)preg_match('/not a readable image|Unsupported image type|Only JPG/i', strip_tags($resp)), 'a disguised PHP file is rejected');
check((string)$pdo->query("SELECT COALESCE(image,'') FROM promo_slides WHERE id=$cardId")->fetchColumn() === $imgBefore,
    'the existing image is untouched after a rejected upload');
@unlink($bad);

$edit = req("$B/admin/homepage.php?edit=$cardId");
$resp = req("$B/admin/homepage.php?edit=$cardId", http_build_query([
    'csrf_token' => tok($edit), 'form' => 'save', 'id' => $cardId,
    'title' => 'Card', 'button_text' => 'Click', 'button_url' => 'javascript:alert(1)',
    'overlay' => '70', 'status' => '1',
]), false);
check((bool)preg_match('/link type is not allowed/i', strip_tags($resp)), 'javascript: links are blocked');

$resp = req("$B/admin/homepage.php", http_build_query(['form' => 'delete', 'id' => $cardId]), false);
check((int)$pdo->query("SELECT COUNT(*) FROM promo_slides WHERE id=$cardId")->fetchColumn() === 1,
    'a request without a CSRF token changes nothing');

$restore();
@unlink($png);
$h = home();
check(str_contains($h, 'slide-flash.jpg'), 'defaults restored and rendering');

echo "\n" . str_repeat('=', 52) . "\n";
echo "Promo manager: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
