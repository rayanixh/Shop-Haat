import asyncio, sys
from playwright.async_api import async_playwright
WIDTHS=[320,360,414,768,1024,1440,1920]
PAGES=['dashboard.php','homepage.php','homepage.php?edit=1','products.php','categories.php','brands.php','digital-codes.php',
       'coupons.php','orders.php','payments.php','customers.php','customers.php?id=1',
       'payment-methods.php','payment-gateways.php','telegram.php','whatsapp.php',
       'messenger.php','email.php','notifications.php','settings.php','logs.php']
async def main():
    bad=[]
    async with async_playwright() as p:
        b=await p.chromium.launch()
        ctx=await b.new_context(viewport={'width':1280,'height':900})
        pg=await ctx.new_page()
        await pg.goto('http://127.0.0.1:8080/admin/login.php',wait_until='networkidle')
        await pg.fill('input[name=email]','admin@shophaat.test')
        await pg.fill('input[name=password]','AdminPass123')
        await pg.click('button[type=submit]'); await pg.wait_for_load_state('networkidle')
        for w in WIDTHS:
            await pg.set_viewport_size({'width':w,'height':900})
            for path in PAGES:
                errs=[]
                pg.on('pageerror', lambda e: errs.append(str(e)))
                await pg.goto('http://127.0.0.1:8080/admin/'+path,wait_until='networkidle',timeout=40000)
                ov=await pg.evaluate("()=>({sw:Math.max(document.body.scrollWidth,document.documentElement.clientWidth),cw:document.documentElement.clientWidth})")
                if ov['sw']>ov['cw']+1:
                    culp=await pg.evaluate("""()=>{const w=document.documentElement.clientWidth;
                      const inS=e=>{let p=e.parentElement;while(p){const o=getComputedStyle(p).overflowX;
                        if(o==='auto'||o==='scroll'||o==='hidden')return true;p=p.parentElement;}return false;};
                      return [...document.querySelectorAll('*')].filter(e=>e.getBoundingClientRect().right>w+1&&!inS(e))
                        .slice(0,3).map(e=>e.tagName+'.'+(e.className||'').toString().slice(0,35));}""")
                    bad.append(f"OVERFLOW {path} @{w}px sw={ov['sw']} :: {culp}")
                clip=await pg.evaluate("""()=>[...document.querySelectorAll('.sh-stat__label,.sh-stat__value,.sh-chancard__name,.sh-statuspill,.sh-panel__title')]
                    .filter(e=>e.scrollWidth>e.clientWidth+1).slice(0,3)
                    .map(e=>(e.className||'').toString().slice(0,28)+': '+e.textContent.trim().slice(0,24))""")
                if clip: bad.append(f"CLIPPED  {path} @{w}px :: {clip}")
                if errs: bad.append(f"JSERROR  {path} @{w}px :: {errs[:1]}")
        await b.close()
    if bad:
        print("ISSUES FOUND:"); [print("  -",x) for x in bad]
        sys.exit(1)
    print(f"Clean: {len(PAGES)} admin pages x {len(WIDTHS)} widths — no overflow, no clipped text, no JS errors.")
asyncio.run(main())
