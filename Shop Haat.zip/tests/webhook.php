<?php
/**
 * Meta WhatsApp Cloud API webhook.
 *
 * Covers the full test matrix: verification handshake, event ingestion,
 * de-duplication, every message type, hostile input, signature checking and
 * secret containment. The endpoint must NEVER answer 500.
 */
declare(strict_types=1);
$B = 'http://127.0.0.1:8080';
$WH = $B . '/webhook.php';
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
// This connection reads rows written by a SEPARATE webhook process. Under the
// default REPEATABLE READ isolation a long-lived connection keeps its original
// snapshot and never sees them, so read committed data instead.
$pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED');
function setting(PDO $p, string $k, string $v): void {
    $p->prepare('INSERT INTO settings (setting_key,setting_value) VALUES (?,?)
                 ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)')->execute([$k, $v]);
}
function get_setting(PDO $p, string $k): string {
    $st = $p->prepare('SELECT setting_value FROM settings WHERE setting_key=?');
    $st->execute([$k]);
    return (string)($st->fetchColumn() ?: '');
}


/**
 * The webhook returns 200 to Meta before finishing its database work, so a test
 * that reads instantly can race it. Poll briefly for the expected row.
 */
function wait_for(PDO $pdo, string $sql, array $args = [], int $tries = 25): bool {
    for ($i = 0; $i < $tries; $i++) {
        $st = $pdo->prepare($sql);
        $st->execute($args);
        if ((int)$st->fetchColumn() > 0) { return true; }
        usleep(100000);
    }
    return false;
}

function req(string $url, ?string $body = null, array $headers = [], string $method = ''): array {
    $ch = curl_init($url);
    $opts = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_HTTPHEADER => $headers];
    if ($body !== null) { $opts[CURLOPT_POST] = true; $opts[CURLOPT_POSTFIELDS] = $body; }
    if ($method !== '') { $opts[CURLOPT_CUSTOMREQUEST] = $method; }
    curl_setopt_array($ch, $opts);
    $out = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => $out];
}
function post(string $url, string $json, array $h = []): array {
    return req($url, $json, array_merge(['Content-Type: application/json'], $h));
}
function evt(array $value): string {
    return json_encode(['object' => 'whatsapp_business_account',
        'entry' => [['id' => 'WABA_TEST', 'changes' => [['field' => 'messages', 'value' => $value]]]]]);
}

// Snapshot settings so the suite restores everything it touches.
$keys = ['whatsapp_verify_token','whatsapp_app_secret','whatsapp_webhook_debug','whatsapp_token'];
$saved = [];
foreach ($keys as $k) { $saved[$k] = get_setting($pdo, $k); }
$VERIFY = 'test_verify_' . bin2hex(random_bytes(6));
setting($pdo, 'whatsapp_verify_token', $VERIFY);
setting($pdo, 'whatsapp_app_secret', '');
setting($pdo, 'whatsapp_webhook_debug', '1');
$pdo->exec("DELETE FROM whatsapp_messages WHERE message_id LIKE 'wamid.SUITE%'");
$pdo->exec("DELETE FROM whatsapp_message_statuses WHERE message_id LIKE 'wamid.SUITE%'");

echo "\n\033[1m1. GET — Meta verification handshake\033[0m\n";
$r = req("$WH?hub.mode=subscribe&hub.verify_token=" . urlencode($VERIFY) . "&hub.challenge=CHALLENGE_42");
check($r['code'] === 200, 'valid token returns HTTP 200', "got {$r['code']}");
check(trim($r['body']) === 'CHALLENGE_42', 'the raw challenge is echoed back', trim($r['body']));

$r = req("$WH?hub.mode=subscribe&hub.verify_token=wrong_token&hub.challenge=CHALLENGE_42");
check($r['code'] === 403, 'invalid token returns HTTP 403', "got {$r['code']}");
check(!str_contains($r['body'], 'CHALLENGE_42'), 'the challenge is NOT echoed on failure');

$r = req("$WH?hub.mode=unsubscribe&hub.verify_token=" . urlencode($VERIFY) . "&hub.challenge=X");
check($r['code'] === 403, 'wrong hub.mode returns HTTP 403', "got {$r['code']}");

$r = req($WH);
check($r['code'] === 200 && !str_contains($r['body'], $VERIFY), 'a bare GET is a safe liveness reply');

$r = req($WH, null, [], 'DELETE');
check($r['code'] === 405, 'unsupported HTTP methods return 405', "got {$r['code']}");

echo "\n\033[1m2. POST — inbound messages\033[0m\n";
$mid = 'wamid.SUITE_TEXT';
$r = post($WH, evt([
    'messaging_product' => 'whatsapp',
    'metadata' => ['display_phone_number' => '8801700000000', 'phone_number_id' => '1234567890'],
    'contacts' => [['profile' => ['name' => 'Suite Tester'], 'wa_id' => '8801812345678']],
    'messages' => [['from' => '8801812345678', 'id' => $mid, 'timestamp' => '1788500000',
                    'type' => 'text', 'text' => ['body' => 'Is this in stock?']]],
]));
check($r['code'] === 200, 'a valid event returns HTTP 200', "got {$r['code']}");
wait_for($pdo, 'SELECT COUNT(*) FROM whatsapp_messages WHERE message_id = ?', [$mid]);
$row = $pdo->query("SELECT * FROM whatsapp_messages WHERE message_id=" . $pdo->quote($mid))->fetch(PDO::FETCH_ASSOC);
check($row !== false, 'the message is stored');
check(($row['phone_number'] ?? '') === '8801812345678', 'sender phone captured');
check(($row['contact_name'] ?? '') === 'Suite Tester', 'contact name captured');
check(($row['message_text'] ?? '') === 'Is this in stock?', 'text extracted');
check(($row['wa_timestamp'] ?? '') !== '', 'timestamp captured');

post($WH, evt([
    'contacts' => [['profile' => ['name' => 'Suite Tester'], 'wa_id' => '8801812345678']],
    'messages' => [['from' => '8801812345678', 'id' => $mid, 'timestamp' => '1788500000',
                    'type' => 'text', 'text' => ['body' => 'Is this in stock?']]],
]));
usleep(400000);
$n = (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_messages WHERE message_id=" . $pdo->quote($mid))->fetchColumn();
check($n === 1, 'a repeated event does not duplicate the row', "rows: $n");

echo "\n\033[1m3. POST — delivery statuses\033[0m\n";
foreach (['sent', 'delivered', 'read'] as $state) {
    post($WH, evt(['statuses' => [[
        'id' => $mid, 'status' => $state, 'timestamp' => '1788500100', 'recipient_id' => '8801812345678']]]));
}
for ($i = 0; $i < 25; $i++) {
    $n = (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_message_statuses WHERE message_id=" . $pdo->quote($mid))->fetchColumn();
    if ($n >= 3) { break; }
    usleep(100000);
}
check($n === 3, 'sent/delivered/read all recorded', "rows: $n");
post($WH, evt(['statuses' => [['id' => $mid, 'status' => 'read', 'timestamp' => '1788500100', 'recipient_id' => '8801812345678']]]));
usleep(400000);
$n2 = (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_message_statuses WHERE message_id=" . $pdo->quote($mid))->fetchColumn();
check($n2 === 3, 'a repeated status does not duplicate', "rows: $n2");
usleep(200000);
$cur = (string)$pdo->query("SELECT status FROM whatsapp_messages WHERE message_id=" . $pdo->quote($mid))->fetchColumn();
check($cur === 'read', 'the message row mirrors the latest status', $cur);

$r = post($WH, evt(['statuses' => [[
    'id' => 'wamid.SUITE_FAIL', 'status' => 'failed', 'timestamp' => '1788500200',
    'recipient_id' => '8801812345678',
    'errors' => [['code' => 131047, 'title' => 'Re-engagement message']]]]]));
wait_for($pdo, "SELECT COUNT(*) FROM whatsapp_message_statuses WHERE message_id='wamid.SUITE_FAIL'");
$err = $pdo->query("SELECT error_title FROM whatsapp_message_statuses WHERE message_id='wamid.SUITE_FAIL'")->fetchColumn();
check($err === 'Re-engagement message', 'failure reason is captured', (string)$err);

echo "\n\033[1m4. Every message type is handled\033[0m\n";
$types = [
    'image'       => ['image' => ['id' => 'm1', 'caption' => 'a photo']],
    'video'       => ['video' => ['id' => 'm2']],
    'audio'       => ['audio' => ['id' => 'm3']],
    'document'    => ['document' => ['filename' => 'invoice.pdf']],
    'sticker'     => ['sticker' => ['id' => 'm5']],
    'location'    => ['location' => ['latitude' => 23.81, 'longitude' => 90.41, 'name' => 'Dhaka']],
    'contacts'    => ['contacts' => [['name' => ['formatted_name' => 'Karim']]]],
    'interactive' => ['interactive' => ['type' => 'button_reply', 'button_reply' => ['id' => 'b', 'title' => 'Yes']]],
    'button'      => ['button' => ['text' => 'Order now', 'payload' => 'ORD']],
    'reaction'    => ['reaction' => ['message_id' => 'x', 'emoji' => "\u{1F44D}"]],
    'unsupported' => ['errors' => [['title' => 'Not supported']]],
    'quantum_odd' => ['quantum_odd' => ['a' => 1]],
];
$i = 0; $stored = 0;
foreach ($types as $type => $extra) {
    $i++;
    $id = 'wamid.SUITE_T' . $i;
    $r = post($WH, evt(['messages' => [array_merge(
        ['from' => '880171000000' . $i, 'id' => $id, 'timestamp' => '1788501000', 'type' => $type], $extra)]]));
    if ($r['code'] !== 200) { bad("type \"$type\" returned HTTP {$r['code']}"); continue; }
    wait_for($pdo, 'SELECT COUNT(*) FROM whatsapp_messages WHERE message_id = ?', [$id]);
    $got = $pdo->query("SELECT message_text FROM whatsapp_messages WHERE message_id=" . $pdo->quote($id))->fetchColumn();
    if ($got !== false && $got !== '') { $stored++; }
}
check($stored === count($types), 'all ' . count($types) . ' message types stored with readable text', "stored: $stored");
$emoji = (string)$pdo->query("SELECT message_text FROM whatsapp_messages WHERE message_type='reaction' ORDER BY id DESC LIMIT 1")->fetchColumn();
check(str_contains($emoji, "\u{1F44D}"), 'emoji survives storage as UTF-8');

echo "\n\033[1m5. Hostile and malformed input never 500s\033[0m\n";
$cases = [
    'invalid JSON'            => '{"object":',
    'empty body'              => '',
    'JSON scalar'             => '"a string"',
    'JSON array'              => '[1,2,3]',
    'missing entry'           => '{"object":"whatsapp_business_account"}',
    'entry not an array'      => '{"object":"whatsapp_business_account","entry":"nope"}',
    'null collections'        => '{"object":"whatsapp_business_account","entry":[{"changes":[{"value":{"messages":null,"statuses":null}}]}]}',
    'message without id'      => '{"object":"whatsapp_business_account","entry":[{"changes":[{"value":{"messages":[{"from":"88","type":"text"}]}}]}]}',
    'message without type'    => '{"object":"whatsapp_business_account","entry":[{"changes":[{"value":{"messages":[{"id":"wamid.SUITE_BARE","from":"88"}]}}]}]}',
    'foreign object (page)'   => '{"object":"page","entry":[{"messaging":[]}]}',
    'deeply nested nulls'     => '{"object":"whatsapp_business_account","entry":[null,{"changes":[null,{"value":null}]}]}',
];
$all200 = true;
foreach ($cases as $label => $body) {
    $r = post($WH, $body);
    if ($r['code'] !== 200) { bad("\"$label\" returned HTTP {$r['code']} (must be 200)"); $all200 = false; }
    if (preg_match('/Fatal error|Stack trace|SQLSTATE|\/home\//i', $r['body'])) {
        bad("\"$label\" leaked internals"); $all200 = false;
    }
}
if ($all200) { ok('all ' . count($cases) . ' malformed payloads answered 200 with no leakage'); }

$r = post($WH, str_repeat('x', 200000));
check($r['code'] === 200, 'a large junk body is handled without a 500', "got {$r['code']}");

echo "\n\033[1m6. Signature verification (X-Hub-Signature-256)\033[0m\n";
// Store the app secret the way the admin does, so decryption is exercised too.
$secret = 'suite_app_secret_' . bin2hex(random_bytes(4));
$enc = shell_exec('php -r ' . escapeshellarg(
    'require "/home/user/shop/config/config.php"; require SH_ROOT."/includes/whatsapp.php"; echo sh_wa_encrypt($argv[1]);'
) . ' ' . escapeshellarg($secret));
setting($pdo, 'whatsapp_app_secret', trim((string)$enc));

$body = evt(['messages' => [['from' => '8801999', 'id' => 'wamid.SUITE_SIGNED',
    'timestamp' => '1788502000', 'type' => 'text', 'text' => ['body' => 'signed']]]]);
$good = hash_hmac('sha256', $body, $secret);

$r = post($WH, $body, ['X-Hub-Signature-256: sha256=' . $good]);
check($r['code'] === 200, 'a correctly signed payload is accepted', "got {$r['code']}");
check(wait_for($pdo, "SELECT COUNT(*) FROM whatsapp_messages WHERE message_id='wamid.SUITE_SIGNED'"),
    'the signed message is stored');

$r = post($WH, evt(['messages' => [['from' => '8801999', 'id' => 'wamid.SUITE_BADSIG',
    'timestamp' => '1788502100', 'type' => 'text', 'text' => ['body' => 'nope']]]]),
    ['X-Hub-Signature-256: sha256=deadbeef']);
check($r['code'] === 403, 'a wrongly signed payload is rejected with 403', "got {$r['code']}");
check((int)$pdo->query("SELECT COUNT(*) FROM whatsapp_messages WHERE message_id='wamid.SUITE_BADSIG'")->fetchColumn() === 0,
    'a rejected payload is never stored');

$r = post($WH, $body);
check($r['code'] === 403, 'an unsigned payload is rejected while a secret is set', "got {$r['code']}");
setting($pdo, 'whatsapp_app_secret', '');

echo "\n\033[1m7. Secrets never escape\033[0m\n";
$token = 'EAAG_suite_secret_token_' . bin2hex(random_bytes(6));
$encTok = shell_exec('php -r ' . escapeshellarg(
    'require "/home/user/shop/config/config.php"; require SH_ROOT."/includes/whatsapp.php"; echo sh_wa_encrypt($argv[1]);'
) . ' ' . escapeshellarg($token));
setting($pdo, 'whatsapp_token', trim((string)$encTok));

$rawInDb = (int)$pdo->query('SELECT COUNT(*) FROM settings WHERE setting_value LIKE ' . $pdo->quote('%' . $token . '%'))->fetchColumn();
check($rawInDb === 0, 'the access token is encrypted at rest, not plain text');

$roundTrip = trim((string)shell_exec('php -r ' . escapeshellarg(
    'require "/home/user/shop/config/config.php"; require SH_ROOT."/includes/whatsapp.php"; echo sh_wa_access_token();')));
check($roundTrip === $token, 'the token decrypts correctly server-side');

foreach ([$WH, "$WH?hub.mode=subscribe&hub.verify_token=$VERIFY&hub.challenge=Z", $B . '/', $B . '/assets/js/app.js'] as $u) {
    $r = req($u);
    if (str_contains($r['body'], $token)) { bad("the access token leaked from $u"); }
}
ok('the access token appears in no public response');

$logFile = '/home/user/shop/logs/app-' . date('Y-m-d') . '.log';
$log = is_file($logFile) ? (string)file_get_contents($logFile) : '';
check(!str_contains($log, $token), 'the access token never reaches the log file');
check(!str_contains($log, $secret), 'the app secret never reaches the log file');
$recent = substr($log, -6000);
check(!str_contains($recent, 'hub.verify_token=' . $VERIFY), 'the verify token is masked in recent log URLs');

echo "\n\033[1m8. Health check reports safely\033[0m\n";
$health = shell_exec('php -r ' . escapeshellarg(
    'require "/home/user/shop/config/config.php"; require SH_ROOT."/includes/whatsapp.php";
     foreach (sh_wa_health() as $h) { echo ($h["ok"]?"OK":"NO"), "|", $h["label"], "|", $h["value"], "\n"; }'));
check(str_contains((string)$health, 'Webhook tables'), 'health check inspects the webhook tables');
check(str_contains((string)$health, 'Database connection'), 'health check inspects the database');
check(!str_contains((string)$health, $token), 'health check exposes no secrets');

// restore
foreach ($saved as $k => $v) { setting($pdo, $k, $v); }
$pdo->exec("DELETE FROM whatsapp_messages WHERE message_id LIKE 'wamid.SUITE%'");
$pdo->exec("DELETE FROM whatsapp_message_statuses WHERE message_id LIKE 'wamid.SUITE%'");

echo "\n" . str_repeat('=', 52) . "\n";
echo "WhatsApp webhook: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
