import asyncio, sys
from playwright.async_api import async_playwright
WIDTHS=[320,360,414,600,768,1024,1280,1440,1920]
PAGES=[('/','home'),('/products.php','listing'),('/cart.php','cart'),('/login.php','login'),
       ('/help.php','help'),('/track.php','track'),('/register.php','register')]
async def main():
    bad=[]
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for path,name in PAGES:
            for w in WIDTHS:
                pg=await b.new_page(viewport={'width':w,'height':900})
                errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
                await pg.goto('http://127.0.0.1:8080'+path,wait_until='networkidle',timeout=40000)
                ov=await pg.evaluate("()=>({sw:Math.max(document.body.scrollWidth,document.documentElement.clientWidth),cw:document.documentElement.clientWidth})")
                if ov['sw']>ov['cw']+1:
                    culp=await pg.evaluate("""()=>{const w=document.documentElement.clientWidth;
                      const inS=e=>{let p=e.parentElement;while(p){const o=getComputedStyle(p).overflowX;
                        if(o==='auto'||o==='scroll'||o==='hidden')return true;p=p.parentElement;}return false;};
                      return [...document.querySelectorAll('*')].filter(e=>e.getBoundingClientRect().right>w+1&&!inS(e))
                        .slice(0,3).map(e=>e.tagName+'.'+(e.className||'').toString().slice(0,35));}""")
                    bad.append(f"{name} @{w}px sw={ov['sw']} :: {culp}")
                if errs: bad.append(f"{name} @{w}px JS: {errs[:1]}")
                await pg.close()
        await b.close()
    if bad:
        print("ISSUES:"); [print("  -",x) for x in bad]; sys.exit(1)
    print(f"Storefront clean: {len(PAGES)} pages x {len(WIDTHS)} widths.")
asyncio.run(main())
