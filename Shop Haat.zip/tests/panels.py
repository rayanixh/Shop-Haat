import asyncio, sys, time
from playwright.async_api import async_playwright
PAGES=['account.php','orders.php','addresses.php','wishlist.php','digital.php','password.php']
async def main():
    bad=[]
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':390,'height':900})
        pg=await ctx.new_page()
        await pg.goto('http://127.0.0.1:8080/register.php', wait_until='networkidle')
        em=f'ui{time.time_ns()}@t.local'
        await pg.fill('input[name=name]','UI Tester'); await pg.fill('input[name=email]',em)
        await pg.fill('input[name=phone]','01712345678')
        await pg.fill('input[name=password]','TestPass123'); await pg.fill('input[name=password2]','TestPass123')
        await pg.check('input[name=terms]')
        await pg.click('.sh-authcard button[type=submit], main form button[type=submit]')
        await pg.wait_for_load_state('networkidle')
        for w in [320,360,390,414,768,1024,1440]:
            await pg.set_viewport_size({'width':w,'height':900})
            for path in PAGES:
                await pg.goto(f'http://127.0.0.1:8080/{path}', wait_until='networkidle')
                ov=await pg.evaluate("()=>({sw:Math.max(document.body.scrollWidth,document.documentElement.clientWidth),cw:document.documentElement.clientWidth})")
                if ov['sw']>ov['cw']+1: bad.append(f"OVERFLOW {path}@{w} {ov['sw']}/{ov['cw']}")
                clip=await pg.evaluate("""()=>[...document.querySelectorAll('.sh-stat__label,.sh-stat__value,.sh-account__link,.sh-track__label')]
                    .filter(e=>e.scrollWidth>e.clientWidth+1).slice(0,3).map(e=>e.textContent.trim().slice(0,22))""")
                if clip: bad.append(f"CLIPPED {path}@{w} {clip}")
                sc=await pg.evaluate("""()=>[...document.querySelectorAll('*')].filter(e=>{const s=getComputedStyle(e);
                    return (s.overflowX==='auto'||s.overflowX==='scroll')&&e.scrollWidth>e.clientWidth+2&&!e.closest('.sh-tablewrap,.sh-table-wrap,.sh-nav,.sh-header');})
                    .map(e=>e.tagName+'.'+(e.className||'').toString().slice(0,30))""")
                if sc: bad.append(f"SLIDER {path}@{w} {sc}")

        # --- ADMIN PANEL ---
        ap=await ctx.new_page()
        await ap.goto('http://127.0.0.1:8080/admin/login.php', wait_until='networkidle')
        await ap.fill('input[name=email]','admin@shophaat.test'); await ap.fill('input[name=password]','AdminPass123')
        await ap.click('button[type=submit]'); await ap.wait_for_load_state('networkidle')
        ADMIN=['dashboard.php','homepage.php','products.php','orders.php','payments.php','customers.php',
               'notifications.php','settings.php','telegram.php','payment-methods.php']
        for w in [360,390,768,1440]:
            await ap.set_viewport_size({'width':w,'height':900})
            for path in ADMIN:
                await ap.goto('http://127.0.0.1:8080/admin/'+path, wait_until='networkidle', timeout=40000)
                sc=await ap.evaluate("""()=>[...document.querySelectorAll('*')].filter(e=>{const s=getComputedStyle(e);
                    return (s.overflowX==='auto'||s.overflowX==='scroll')&&e.scrollWidth>e.clientWidth+2
                      && !e.closest('.sh-tablewrap,.sh-table-wrap,.sh-nav,.sh-header');})
                    .map(e=>e.tagName+'.'+(e.className||'').toString().slice(0,34))""")
                if sc: bad.append(f"ADMIN SLIDER {path}@{w} {sc}")
                car=await ap.evaluate("()=>document.querySelectorAll('[data-carousel],.sh-carousel,.sh-slide').length")
                if car: bad.append(f"ADMIN CAROUSEL {path}@{w} ({car} elements)")

        # --- HOMEPAGE SLIDER MUST SURVIVE ---
        hp=await ctx.new_page()
        await hp.goto('http://127.0.0.1:8080/', wait_until='networkidle')
        for sel,label in [('[data-carousel]','carousel container'),('.sh-slide','slides'),
                          ('[data-carousel-next]','next arrow'),('.sh-carousel__dot','dots')]:
            n=await hp.locator(sel).count()
            if n==0: bad.append(f"HOMEPAGE lost its {label}")
        await b.close()

    if bad:
        print("ISSUES:"); [print("  -",x) for x in bad]; sys.exit(1)
    print(f"Account panel: {len(PAGES)} pages x 7 widths — static boxes, no sliders.")
    print("Admin panel: 10 pages x 4 widths — static boxes, no carousels.")
    print("Homepage slider: still present (carousel, slides, arrows, dots).")
asyncio.run(main())
