<?php
/**
 * Admin-managed category images.
 *
 * Proves the homepage cards are database-driven: upload through the real admin
 * form, confirm the frontend changes, and confirm the fallback, cleanup and
 * upload-security rules all hold.
 */
declare(strict_types=1);
$B = 'http://127.0.0.1:8080';
$ROOT = '/home/user/shop';
$DIR = $ROOT . '/uploads/categories';
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

$J = '/tmp/catimg-adm.txt'; @unlink($J);
function req(string $url, $post = null, bool $follow = true): string {
    global $J;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J,
        CURLOPT_COOKIEFILE => $J, CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_TIMEOUT => 40]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
    $b = (string)curl_exec($ch); curl_close($ch);
    return $b;
}
function tok(string $h): string { return preg_match('/name="csrf_token" value="([^"]+)"/', $h, $m) ? $m[1] : ''; }
function home(): string { return (string)file_get_contents('http://127.0.0.1:8080/'); }

function makePng(string $path, int $w = 300, int $h = 300): void {
    $chunk = static fn(string $t, string $d): string => pack('N', strlen($d)) . $t . $d . pack('N', crc32($t . $d));
    $raw = '';
    for ($y = 0; $y < $h; $y++) { $raw .= "\x00" . str_repeat("\x14\x78\xDC", $w); }
    file_put_contents($path, "\x89PNG\r\n\x1a\n"
        . $chunk('IHDR', pack('NNCCCCC', $w, $h, 8, 2, 0, 0, 0))
        . $chunk('IDAT', gzcompress($raw)) . $chunk('IEND', ''));
}
$png = '/tmp/catimg-test.png';
makePng($png);

$row = $pdo->query('SELECT * FROM categories ORDER BY sort_order LIMIT 1')->fetch(PDO::FETCH_ASSOC);
if (!$row) { echo "  no categories to test\n"; exit(0); }
$id = (int)$row['id'];
$original = $row['image'];

function saveCategory(string $B, array $row, ?string $file, bool $remove = false): string {
    $id = (int)$row['id'];
    $form = req("$B/admin/categories.php?edit=$id");
    $fields = ['csrf_token' => tok($form), 'form' => 'save', 'id' => (string)$id,
        'name' => (string)$row['name'], 'slug' => (string)$row['slug'],
        'icon' => (string)($row['icon'] ?: 'grid'), 'sort_order' => (string)$row['sort_order'], 'status' => '1'];
    if ($remove) { $fields['remove_image'] = '1'; }
    if ($file !== null) { $fields['image'] = new CURLFile($file, 'image/png', 'category.png'); }
    return req("$B/admin/categories.php?edit=$id", $fields, false);
}

$p = req("$B/admin/login.php");
req("$B/admin/login.php", http_build_query(['csrf_token' => tok($p),
    'email' => 'admin@shophaat.test', 'password' => 'AdminPass123']));
check(str_contains(req("$B/admin/categories.php"), 'Categories'), 'admin categories page loads');

echo "\n\033[1m1. The frontend is database-driven, not hard-coded\033[0m\n";
$src = (string)file_get_contents($ROOT . '/index.php');
check(str_contains($src, 'sh_category_image('), 'index.php resolves the card image from the database');
check(!preg_match('/sh-category-card__icon"><\?= sh_icon\(\$c\[.icon.\]/', $src),
    'the hard-coded card icon is gone');
$cols = $pdo->query("SHOW COLUMNS FROM categories LIKE 'image'")->fetchAll();
check(count($cols) === 1, 'the existing categories.image column is reused (no duplicate field)');

echo "\n\033[1m2. Uploading an image updates the card\033[0m\n";
saveCategory($B, $row, $png);
$stored = (string)$pdo->query("SELECT COALESCE(image,'') FROM categories WHERE id=$id")->fetchColumn();
check($stored !== '', 'a filename is stored in the database', $stored);
check($stored === basename($stored), 'only the bare filename is stored (no path)', $stored);
check($stored !== '' && is_file($DIR . '/' . $stored), 'the file is written to uploads/categories/');
check($stored !== '' && !str_contains($stored, 'category.png'),
    'the original filename is NOT trusted — a unique name is generated', $stored);

$ch = curl_init("$B/uploads/categories/" . rawurlencode($stored));
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20]);
curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);
check($code === 200 && str_contains($ctype, 'image/'), 'the image is served over HTTP', "$code $ctype");

$h = home();
check(str_contains($h, 'uploads/categories/' . $stored), 'the homepage card shows the uploaded image');
check(str_contains($h, 'sh-category-card__icon--photo'), 'the photo variant class is applied');
check(str_contains($h, 'loading="lazy"'), 'card images are lazy-loaded');

echo "\n\033[1m3. Replacing an image cleans up the old file\033[0m\n";
$old = $stored;
$png2 = '/tmp/catimg-test2.png';
makePng($png2, 500, 200);   // deliberately non-square
saveCategory($B, $row, $png2);
$new = (string)$pdo->query("SELECT COALESCE(image,'') FROM categories WHERE id=$id")->fetchColumn();
check($new !== '' && $new !== $old, 'the database points at the new file', $new);
check(!is_file($DIR . '/' . $old), 'the replaced file is deleted from disk');
check(is_file($DIR . '/' . $new), 'the new file is present');
@unlink($png2);

echo "\n\033[1m4. Removing an image falls back cleanly\033[0m\n";
$form = req("$B/admin/categories.php?edit=$id");
req("$B/admin/categories.php", http_build_query(['csrf_token' => tok($form),
    'form' => 'remove_image', 'id' => $id]), false);
$after = $pdo->query("SELECT image FROM categories WHERE id=$id")->fetchColumn();
check($after === null || $after === '', 'the database value is cleared');
check(!is_file($DIR . '/' . $new), 'the file is deleted');
$h = home();
check(!str_contains($h, 'uploads/categories/' . $new), 'the card no longer references the deleted image');
check(str_contains($h, 'sh-category-card'), 'the category grid still renders (layout intact)');

echo "\n\033[1m5. Upload security\033[0m\n";
$evil = '/tmp/catimg-evil.png';
file_put_contents($evil, '<?php echo "hack"; ?>');
$before = (string)$pdo->query("SELECT COALESCE(image,'') FROM categories WHERE id=$id")->fetchColumn();
$resp = saveCategory($B, $row, $evil);
check((bool)preg_match('/not a readable image|Unsupported image type|Only JPG/i', strip_tags($resp)),
    'a PHP file renamed .png is rejected with a reason');
check((string)$pdo->query("SELECT COALESCE(image,'') FROM categories WHERE id=$id")->fetchColumn() === $before,
    'the rejected upload does not change the stored image');
$leftovers = array_filter(glob($DIR . '/*') ?: [], static fn($f) => str_contains((string)file_get_contents($f), '<?php'));
check(!$leftovers, 'no executable file is left in the uploads folder');
@unlink($evil);

// Path traversal must not escape the uploads folder.
$probe = $ROOT . '/_catprobe.php';
file_put_contents($probe, "<?php require __DIR__.'/config/config.php'; header('Content-Type: text/plain');"
    . " echo sh_category_image('../../config/database.php'), '|', sh_category_image('../.htaccess'), '|END';");
$out = (string)file_get_contents("$B/_catprobe.php");
@unlink($probe);
check(str_starts_with($out, '||END'), 'path traversal in a stored value resolves to nothing', trim($out));

echo "\n\033[1m6. Existing category functionality still works\033[0m\n";
$count = (int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
$newName = 'Test Cat ' . bin2hex(random_bytes(3));
$form = req("$B/admin/categories.php");
req("$B/admin/categories.php", ['csrf_token' => tok($form), 'form' => 'save', 'id' => '0',
    'name' => $newName, 'slug' => '', 'icon' => 'grid', 'sort_order' => '99', 'status' => '1'], false);
$after = (int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
check($after === $count + 1, 'a category can still be created without an image');
$newId = (int)$pdo->query('SELECT id FROM categories WHERE name=' . $pdo->quote($newName))->fetchColumn();
$form = req("$B/admin/categories.php");
req("$B/admin/categories.php", http_build_query(['csrf_token' => tok($form), 'form' => 'delete', 'id' => $newId]), false);
check((int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn() === $count,
    'a category can still be deleted');
$prod = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE category_id=$id")->fetchColumn();
check($prod > 0, 'product-category relationships are untouched', "products: $prod");
check((bool)preg_match('/\d+ items/', home()), 'item counts still render on the cards');

// restore
if ($original === null || $original === '') { $pdo->exec("UPDATE categories SET image=NULL WHERE id=$id"); }
else { $pdo->prepare("UPDATE categories SET image=? WHERE id=$id")->execute([$original]); }
@unlink($png);

echo "\n" . str_repeat('=', 52) . "\n";
echo "Category images: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
