<?php
/**
 * End-to-end flow: register -> add to cart -> checkout -> manual payment ->
 * admin approves -> digital code delivered exactly once -> IDOR blocked.
 */
declare(strict_types=1);
$BASE = 'http://127.0.0.1:8080';
$CJ = '/tmp/e2e-cust.txt'; $AJ = '/tmp/e2e-adm.txt';
@unlink($CJ); @unlink($AJ);

$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): bool { $c ? ok($m) : bad($m, $d); return $c; }

function req(string $url, string $jar, ?array $post = null, bool $follow = true): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar, CURLOPT_COOKIEFILE => $jar,
        CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_TIMEOUT => 30]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post)); }
    $b = curl_exec($ch);
    $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $u = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    return ['code' => $c, 'body' => (string)$b, 'url' => $u];
}
function tok(string $body): string {
    return preg_match('/name="csrf_token" value="([^"]+)"/', $body, $m) ? $m[1] : '';
}

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

echo "\n\033[1m1. Customer registration\033[0m\n";
$email = 'e2e' . time() . '@test.local';
$r = req("$BASE/register.php", $CJ);
$r = req("$BASE/register.php", $CJ, ['csrf_token' => tok($r['body']), 'name' => 'E2E Buyer',
    'email' => $email, 'phone' => '01712345678', 'password' => 'BuyerPass123',
    'password2' => 'BuyerPass123', 'terms' => '1']);
$uid = (int)$pdo->query("SELECT id FROM users WHERE email=" . $pdo->quote($email))->fetchColumn();
check($uid > 0, 'customer account created in DB');
$hash = (string)$pdo->query("SELECT password_hash FROM users WHERE id=$uid")->fetchColumn();
check(str_starts_with($hash, '$2y$') || str_starts_with($hash, '$argon'), 'password stored as a hash, not plaintext');

echo "\n\033[1m2. Add a digital product to the cart\033[0m\n";
$prod = $pdo->query("SELECT p.id,p.slug,p.name,p.price FROM products p
    WHERE p.product_type='digital' AND p.status=1
      AND (SELECT COUNT(*) FROM product_codes c WHERE c.product_id=p.id AND c.status='available')>0
    LIMIT 1")->fetch(PDO::FETCH_ASSOC);
if (!$prod) { bad('no digital product with codes available'); goto done; }
$codesBefore = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE product_id={$prod['id']} AND status='available'")->fetchColumn();

$r = req("$BASE/product.php?slug=" . urlencode($prod['slug']), $CJ);
$csrf = tok($r['body']);
$r = req("$BASE/api/cart.php", $CJ, ['csrf_token' => $csrf, 'action' => 'add', 'product_id' => $prod['id'], 'quantity' => 1]);
$j = json_decode($r['body'], true);
check(!empty($j['success']), 'AJAX add-to-cart returned success', substr($r['body'], 0, 120));

$r = req("$BASE/cart.php", $CJ);
check(str_contains($r['body'], htmlspecialchars($prod['name'], ENT_QUOTES)), 'product appears on the cart page');

echo "\n\033[1m3. Checkout with a manual payment method\033[0m\n";
$method = $pdo->query("SELECT id,name FROM payment_methods WHERE type='manual' AND status=1 AND account_number IS NOT NULL LIMIT 1")->fetch(PDO::FETCH_ASSOC);
if (!$method) { bad('no manual payment method configured'); goto done; }

$r = req("$BASE/checkout.php", $CJ);
$csrf = tok($r['body']);
$r = req("$BASE/checkout.php", $CJ, ['csrf_token' => $csrf, 'customer_name' => 'E2E Buyer',
    'customer_email' => $email, 'customer_phone' => '01712345678',
    'address_line' => '12 Test Road', 'city' => 'Dhaka', 'delivery_zone' => 'inside',
    'payment_method_id' => $method['id'], 'note' => 'e2e test']);
$order = $pdo->query("SELECT * FROM orders WHERE user_id=$uid ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
if (!$order) { bad('order was not created', substr(strip_tags($r['body']), 0, 200)); goto done; }
ok('order created: ' . $order['order_number']);
$oid = (int)$order['id'];

// Server-side price integrity
$expected = (float)$pdo->query("SELECT COALESCE(SUM(line_total),0) FROM order_items WHERE order_id=$oid")->fetchColumn();
check(abs((float)$order['subtotal'] - $expected) < 0.01, 'subtotal recalculated server-side from line items');
check((float)$order['subtotal'] == (float)$prod['price'], 'price taken from DB, not from the browser');
check($order['payment_status'] === 'unpaid', 'order starts unpaid');

echo "\n\033[1m4. Submit a manual payment (must NOT auto-verify)\033[0m\n";
$r = req("$BASE/payment.php?id=$oid", $CJ);
check($r['code'] === 200 && str_contains($r['body'], (string)$method['name']), 'payment page shows the chosen method');
check(str_contains($r['body'], 'sh-copy') || str_contains($r['body'], 'data-copy'), 'merchant number has a copy button');
$csrf = tok($r['body']);
$trx = 'E2ETRX' . time();
$r = req("$BASE/payment.php?id=$oid", $CJ, ['csrf_token' => $csrf, 'form' => 'manual',
    'transaction_id' => $trx, 'sender_phone' => '01812345678']);

$pay = $pdo->query("SELECT * FROM payments WHERE order_id=$oid ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
check($pay && $pay['transaction_id'] === $trx, 'payment record stored with the transaction ID');
check($pay && $pay['status'] === 'pending', 'payment is PENDING, not auto-verified');
$o2 = $pdo->query("SELECT status,payment_status,codes_delivered FROM orders WHERE id=$oid")->fetch(PDO::FETCH_ASSOC);
check($o2['payment_status'] === 'submitted', 'order payment_status = submitted');
check((int)$o2['codes_delivered'] === 0, 'NO digital code released before approval');
$codesNow = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE product_id={$prod['id']} AND status='available'")->fetchColumn();
check($codesNow === $codesBefore, 'code pool untouched while payment is pending');

echo "\n\033[1m5. IDOR protection\033[0m\n";
$AJ2 = '/tmp/e2e-other.txt'; @unlink($AJ2);
$other = 'e2eb' . time() . '@test.local';
$r = req("$BASE/register.php", $AJ2);
req("$BASE/register.php", $AJ2, ['csrf_token' => tok($r['body']), 'name' => 'Other Person',
    'email' => $other, 'phone' => '01998765432', 'password' => 'OtherPass123',
    'password2' => 'OtherPass123', 'terms' => '1']);
$r = req("$BASE/order-details.php?id=$oid", $AJ2);
check($r['code'] === 404 || !str_contains($r['body'], $order['order_number']),
    'another customer cannot read this order (IDOR blocked)', "code {$r['code']}");
$r = req("$BASE/admin/dashboard.php", $AJ2);
check(!str_contains($r['body'], 'sh-admin-sidebar'), 'customer cannot reach the admin panel');

echo "\n\033[1m6. Admin approves the payment\033[0m\n";
$r = req("$BASE/admin/login.php", $AJ);
$r = req("$BASE/admin/login.php", $AJ, ['csrf_token' => tok($r['body']),
    'email' => 'admin@shophaat.test', 'password' => 'AdminPass123']);
check(str_contains($r['body'], 'sh-admin-sidebar'), 'admin signed in');

$payId = (int)$pay['id'];
$r = req("$BASE/admin/payments.php?id=$payId", $AJ);
check(str_contains($r['body'], $trx), 'admin sees the submitted transaction ID');
$csrf = tok($r['body']);
$r = req("$BASE/admin/payments.php?id=$payId", $AJ, ['csrf_token' => $csrf, 'id' => $payId,
    'form' => 'approve', 'admin_note' => 'verified against statement']);

$pay2 = $pdo->query("SELECT status,verified_by,verified_at FROM payments WHERE id=$payId")->fetch(PDO::FETCH_ASSOC);
check($pay2['status'] === 'verified', 'payment now verified');
check(!empty($pay2['verified_by']) && !empty($pay2['verified_at']), 'approval records who and when');
$o3 = $pdo->query("SELECT status,payment_status,codes_delivered FROM orders WHERE id=$oid")->fetch(PDO::FETCH_ASSOC);
check($o3['payment_status'] === 'verified', 'order payment_status = verified');

echo "\n\033[1m7. Digital code delivery\033[0m\n";
$delivered = $pdo->query("SELECT * FROM product_codes WHERE order_id=$oid")->fetchAll(PDO::FETCH_ASSOC);
check(count($delivered) === 1, 'exactly one code assigned to the order', 'got ' . count($delivered));
if ($delivered) {
    check($delivered[0]['status'] === 'used', "code marked as used");
    check(!empty($delivered[0]['delivered_at']), 'delivery timestamp recorded');
    $dupes = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE code=" . $pdo->quote($delivered[0]['code']))->fetchColumn();
    check($dupes === 1, 'that code exists only once in the whole system');
    $r = req("$BASE/order-details.php?id=$oid", $CJ);
    check(str_contains($r['body'], htmlspecialchars($delivered[0]['code'], ENT_QUOTES)), 'customer can see their code');
    $r = req("$BASE/order-details.php?id=$oid", $AJ2);
    check(!str_contains($r['body'], htmlspecialchars($delivered[0]['code'], ENT_QUOTES)), 'other customer CANNOT see the code');
}
$after = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE product_id={$prod['id']} AND status='available'")->fetchColumn();
check($after === $codesBefore - 1, 'available pool decreased by exactly one', "before $codesBefore after $after");

echo "\n\033[1m8. Double-approval safety\033[0m\n";
$r = req("$BASE/admin/payments.php?id=$payId", $AJ);
$csrf = tok($r['body']);
req("$BASE/admin/payments.php?id=$payId", $AJ, ['csrf_token' => $csrf, 'id' => $payId, 'form' => 'approve', 'admin_note' => 'again']);
$again = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE order_id=$oid")->fetchColumn();
check($again === count($delivered), 'a second approval does not issue another code');

echo "\n\033[1m9. Notification logging (honesty)\033[0m\n";
// Enable telegram for one event WITHOUT credentials: it must log 'skipped', never 'sent'.
$pdo->exec("UPDATE notifications SET enabled=1 WHERE channel='telegram' AND event='order_completed'");
$before = (int)$pdo->query("SELECT COUNT(*) FROM notification_logs")->fetchColumn();
$r = req("$BASE/admin/orders.php?id=$oid", $AJ);
$c2 = tok($r['body']);
req("$BASE/admin/orders.php?id=$oid", $AJ, ['csrf_token'=>$c2,'id'=>$oid,'form'=>'status','status'=>'completed']);
$after2 = (int)$pdo->query("SELECT COUNT(*) FROM notification_logs")->fetchColumn();
check($after2 > $before, 'an enabled channel records a log row (' . ($after2-$before) . ' new)');
$tg = $pdo->query("SELECT status,error_message FROM notification_logs WHERE channel='telegram' ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
check($tg && $tg['status'] !== 'sent', 'unconfigured Telegram logged as ' . ($tg['status'] ?? 'none') . ', NOT sent');
$ordAfter = $pdo->query("SELECT status FROM orders WHERE id=$oid")->fetchColumn();
check($ordAfter === 'completed', 'order still completed despite the notification not being deliverable');
$logs = $pdo->query("SELECT channel,event,status FROM notification_logs WHERE order_id=$oid")->fetchAll(PDO::FETCH_ASSOC);
$faked = array_filter($logs, fn($l) => $l['status'] === 'sent');
check(count($faked) === 0, 'unconfigured channels are NOT logged as sent');
$creds = (int)$pdo->query("SELECT COUNT(*) FROM notification_logs WHERE error_message LIKE '%shoppass123%' OR error_message LIKE '%bot%token%'")->fetchColumn();
check($creds === 0, 'no credentials leaked into the notification log');

echo "\n\033[1m10. CSRF enforcement\033[0m\n";
$r = req("$BASE/api/cart.php", $CJ, ['action' => 'add', 'product_id' => $prod['id'], 'quantity' => 1, 'csrf_token' => 'bogus']);
$j = json_decode($r['body'], true);
check(empty($j['success']), 'request with a bad CSRF token is rejected');

done:
echo "\n" . str_repeat('=', 50) . "\n";
echo "E2E: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : "0 failed") . "\n";
exit($fail ? 1 : 0);
