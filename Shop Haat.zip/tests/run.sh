#!/usr/bin/env bash
# Boots the PHP dev server and runs the integration test suite against it.
set -u
PORT="${PORT:-8080}"
ROOT="/home/user/shop"

pkill -f "php -S 0.0.0.0:$PORT" >/dev/null 2>&1
sleep 0.4
php -S "0.0.0.0:$PORT" -t "$ROOT" "$ROOT/router.php" >/tmp/phpserver.log 2>&1 &
SRV=$!
for i in $(seq 1 40); do
  curl -s -o /dev/null "http://127.0.0.1:$PORT/" && break
  sleep 0.25
done

php /home/user/tests/suite.php "http://127.0.0.1:$PORT"
RC=$?
kill $SRV >/dev/null 2>&1
exit $RC
