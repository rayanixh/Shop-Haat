<?php
/**
 * Telegram admin control panel.
 *
 * Presses every inline button through the real webhook and asserts the DATABASE
 * actually changed — not just that a message was sent. Also covers authorisation,
 * duplicate protection, invalid transitions and malformed input.
 *
 * Requires the mock Bot API on 127.0.0.1:9020 (started automatically).
 */
declare(strict_types=1);
$B  = 'http://127.0.0.1:8080';
$WH = $B . '/telegram-webhook.php';
$MOCK = '/tmp/tgmock/calls.log';
$SECRET = 'testsecret123';
$ADMIN = '555000111';
$STRANGER = '111222333';

$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

// --- mock provider -------------------------------------------------------
if (!is_dir('/tmp/tgmock')) { mkdir('/tmp/tgmock', 0777, true); }
$probe = @file_get_contents('http://127.0.0.1:9020/ping', false,
    stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]));
if ($probe === false) {
    exec('nohup php -S 127.0.0.1:9020 ' . escapeshellarg(__DIR__ . '/mock/telegram_bot.php') . ' > /dev/null 2>&1 & echo $!');
    for ($i = 0; $i < 20; $i++) {
        usleep(250000);
        $probe = @file_get_contents('http://127.0.0.1:9020/ping', false,
            stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]));
        if ($probe !== false) { break; }
    }
    if ($probe === false) { echo "  \033[33mSKIP\033[0m  mock Bot API unavailable\n"; exit(0); }
}

function setting(PDO $p, string $k, string $v): void {
    $p->prepare('INSERT INTO settings (setting_key,setting_value) VALUES (?,?)
                 ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)')->execute([$k, $v]);
}
function get_setting(PDO $p, string $k): string {
    $st = $p->prepare('SELECT setting_value FROM settings WHERE setting_key=?');
    $st->execute([$k]); return (string)($st->fetchColumn() ?: '');
}
$keys = ['telegram_api_base','telegram_enabled','telegram_bot_token','telegram_chat_id',
         'telegram_admin_ids','telegram_debug','telegram_webhook_secret'];
$saved = [];
foreach ($keys as $k) { $saved[$k] = get_setting($pdo, $k); }
setting($pdo, 'telegram_api_base', 'http://127.0.0.1:9020');
setting($pdo, 'telegram_enabled', '1');
setting($pdo, 'telegram_bot_token', '123456789:AAtestBotToken_abcdefghijklmnop');
setting($pdo, 'telegram_chat_id', $ADMIN);
setting($pdo, 'telegram_admin_ids', $ADMIN . ',777888999');
setting($pdo, 'telegram_debug', '1');
setting($pdo, 'telegram_webhook_secret', $SECRET);

$uid = 90000;
/** Fire a callback_query at the webhook, as Telegram would. */
function press(string $data, string $fromId, bool $secret = true): array {
    global $WH, $SECRET, $uid;
    $uid++;
    $payload = json_encode(['update_id' => $uid, 'callback_query' => [
        'id' => 'cb' . $uid,
        'from' => ['id' => (int)$fromId, 'first_name' => 'Test', 'last_name' => 'Admin'],
        'message' => ['message_id' => 1234, 'chat' => ['id' => (int)$fromId]],
        'data' => $data,
    ]]);
    $h = ['Content-Type: application/json'];
    if ($secret) { $h[] = 'X-Telegram-Bot-Api-Secret-Token: ' . $SECRET; }
    $ch = curl_init($WH);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload, CURLOPT_HTTPHEADER => $h, CURLOPT_TIMEOUT => 30]);
    $b = (string)curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    usleep(500000); // the webhook answers before finishing its work
    return ['code' => $c, 'body' => $b];
}
function sendCmd(string $text, string $fromId): array {
    global $WH, $SECRET, $uid;
    $uid++;
    $payload = json_encode(['update_id' => $uid, 'message' => [
        'message_id' => 1, 'from' => ['id' => (int)$fromId, 'first_name' => 'Test'],
        'chat' => ['id' => (int)$fromId], 'text' => $text]]);
    $ch = curl_init($WH);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload, CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-Telegram-Bot-Api-Secret-Token: ' . $SECRET]]);
    $b = (string)curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    usleep(400000);
    return ['code' => $c, 'body' => $b];
}
function rawPost(string $body, array $headers = []): array {
    global $WH;
    $ch = curl_init($WH);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body, CURLOPT_TIMEOUT => 25,
        CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json'], $headers)]);
    $b = (string)curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return ['code' => $c, 'body' => $b];
}
function order(PDO $p, int $id): array {
    $st = $p->prepare('SELECT * FROM orders WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch(PDO::FETCH_ASSOC) ?: [];
}
function mockCalls(): array {
    global $MOCK;
    if (!is_file($MOCK)) { return []; }
    $out = [];
    foreach (file($MOCK, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
        $d = json_decode($l, true);
        if (is_array($d)) { $out[] = $d; }
    }
    return $out;
}

/** Build a fresh order in a known state, straight through the store's own code. */
function makeOrder(PDO $pdo, bool $digital = true, bool $submitPayment = true): int {
    $script = <<<'PHP'
require_once "/home/user/shop/config/config.php";
require_once SH_ROOT."/includes/payment.php";
require_once SH_ROOT."/includes/cart.php";
sh_session_start();
$digital = $argv[1] === '1'; $submit = $argv[2] === '1';
$sql = $digital
  ? "SELECT id FROM products WHERE product_type='digital' AND status=1
      AND (SELECT COUNT(*) FROM product_codes c WHERE c.product_id=products.id AND c.status='available')>0 LIMIT 1"
  : "SELECT id FROM products WHERE product_type<>'digital' AND status=1 AND stock>0 LIMIT 1";
$pid = (int)sh_val($sql, [], 0);
if ($pid === 0) { echo "ERR:no-product"; exit; }
$add = sh_cart_add($pid, 1);
if (empty($add['ok'])) { echo "ERR:cart:".($add['error'] ?? '?'); exit; }
$m = sh_one("SELECT id FROM payment_methods WHERE type='manual' AND status=1 LIMIT 1");
if ($m === null) { echo "ERR:no-method"; exit; }
$res = sh_create_order([
  'customer_name' => 'TG Tester', 'customer_email' => 'tg'.bin2hex(random_bytes(4)).'@test.local',
  'customer_phone' => '01712345678', 'address_line' => '1 Test Rd', 'city' => 'Dhaka',
  'delivery_zone' => 'inside', 'payment_method_id' => (int)$m['id'], 'note' => '',
]);
if (empty($res['ok'])) { echo "ERR:order:".($res['error'] ?? '?'); exit; }
$oid = (int)$res['order_id'];
if ($submit) { sh_submit_manual_payment($oid, 'TGTRX'.$oid, '01812345678'); }
echo "OK:".$oid;
PHP;
    $tmp = '/tmp/tg_make_order.php';
    file_put_contents($tmp, "<?php\n" . $script);
    $out = (string)shell_exec('php ' . escapeshellarg($tmp) . ' ' . ($digital ? '1' : '0') . ' ' . ($submitPayment ? '1' : '0') . ' 2>&1');
    if (preg_match('/OK:(\d+)/', $out, $m)) { return (int)$m[1]; }
    fwrite(STDERR, "  (order helper said: " . trim(substr($out, -200)) . ")\n");
    return 0;
}

echo "\n\033[1m1. Order card carries real inline buttons\033[0m\n";
@unlink($MOCK);
$oid = makeOrder($pdo, true, false);
check($oid > 0, 'a real order was created through the store', "id: $oid");
if ($oid === 0) { echo "cannot continue\n"; exit(1); }
usleep(300000);
$calls = mockCalls();
$card = null;
foreach ($calls as $c) {
    if ($c['method'] === 'sendMessage' && isset($c['body']['reply_markup'])) { $card = $c; break; }
}
check($card !== null, 'a Telegram card was sent for the new order');
if ($card) {
    $kb = json_decode((string)$card['body']['reply_markup'], true);
    $labels = [];
    foreach (($kb['inline_keyboard'] ?? []) as $row) { foreach ($row as $b) { $labels[] = $b['callback_data']; } }
    check(in_array('payment_verify:' . $oid, $labels, true), 'card offers Payment Verified with the real order id');
    check(in_array('payment_reject:' . $oid, $labels, true), 'card offers Reject Payment');
    check(in_array('order_cancel:' . $oid, $labels, true), 'card offers Cancel');
    check(!str_contains((string)$card['body']['text'], 'AAtestBotToken'), 'the bot token is not in the message');
}
$stored = (string)(order($pdo, $oid)['telegram_message_id'] ?? '');
check($stored !== '', 'the Telegram message id is stored against the order', $stored);

echo "\n\033[1m2. Authorisation\033[0m\n";
$before = order($pdo, $oid);
$r = press('payment_verify:' . $oid, $STRANGER);
check($r['code'] === 200, 'an unauthorised press still returns 200 to Telegram', "got {$r['code']}");
$after = order($pdo, $oid);
check($after['payment_status'] === $before['payment_status'], 'an unauthorised press changes NOTHING in the database');
$denied = (int)$pdo->query("SELECT COUNT(*) FROM telegram_admin_log WHERE result='denied' AND telegram_admin_id='$STRANGER'")->fetchColumn();
check($denied > 0, 'the unauthorised attempt is logged');

echo "\n\033[1m3. Payment verification performs a real database action\033[0m\n";
$oid2 = makeOrder($pdo, true, true);
check((string)order($pdo, $oid2)['payment_status'] === 'submitted', 'order starts with a submitted payment');
press('payment_verify:' . $oid2, $ADMIN);
$o = order($pdo, $oid2);
check($o['payment_status'] === 'verified', 'payment_status is now verified', (string)$o['payment_status']);
// The store's own sh_deliver_digital_codes() completes a fully-delivered digital
// order automatically, so 'completed' is the correct end state here.
check(in_array($o['status'], ['processing', 'completed'], true),
    'order advanced past pending (processing, or completed once codes shipped)', (string)$o['status']);
$payRow = $pdo->query("SELECT status, verified_at FROM payments WHERE order_id=$oid2 ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
check(($payRow['status'] ?? '') === 'verified', 'the payments table was updated');
check(!empty($payRow['verified_at']), 'verification time recorded');
check((int)$pdo->query("SELECT codes_delivered FROM orders WHERE id=$oid2")->fetchColumn() === 1,
    'digital codes were delivered automatically after verification');
$logged = (int)$pdo->query("SELECT COUNT(*) FROM telegram_admin_log WHERE order_id=$oid2 AND action='PAYMENT_VERIFIED'")->fetchColumn();
check($logged === 1, 'the action is in the audit log');

echo "\n\033[1m4. Duplicate protection\033[0m\n";
$codesBefore = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE order_id=$oid2")->fetchColumn();
press('payment_verify:' . $oid2, $ADMIN);
$o = order($pdo, $oid2);
check($o['payment_status'] === 'verified', 'a second verify press leaves the state correct');
$codesAfter = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE order_id=$oid2")->fetchColumn();
check($codesAfter === $codesBefore, 'no extra codes are issued on a repeat press', "$codesBefore -> $codesAfter");
$noop = (int)$pdo->query("SELECT COUNT(*) FROM telegram_admin_log WHERE order_id=$oid2 AND result='noop'")->fetchColumn();
check($noop > 0, 'the repeat is recorded as a no-op');

press('order_delivery:' . $oid2, $ADMIN);
$codes3 = (int)$pdo->query("SELECT COUNT(*) FROM product_codes WHERE order_id=$oid2")->fetchColumn();
check($codes3 === $codesBefore, 'pressing Delivery again issues no further codes');

echo "\n\033[1m5. Complete\033[0m\n";
press('order_complete:' . $oid2, $ADMIN);
check((string)order($pdo, $oid2)['status'] === 'completed', 'order status is completed');
press('order_complete:' . $oid2, $ADMIN);
check((string)order($pdo, $oid2)['status'] === 'completed', 'completing twice is harmless');
$kbAfter = null;
foreach (array_reverse(mockCalls()) as $c) {
    if ($c['method'] === 'editMessageText' && isset($c['body']['reply_markup'])) { $kbAfter = $c; break; }
}
if ($kbAfter) {
    $kb = json_decode((string)$kbAfter['body']['reply_markup'], true);
    $labels = [];
    foreach (($kb['inline_keyboard'] ?? []) as $row) { foreach ($row as $b) { $labels[] = (string)$b['callback_data']; } }
    $hasAction = (bool)array_filter($labels, static fn($l) => str_starts_with($l, 'payment_') || str_starts_with($l, 'order_complete'));
    check(!$hasAction, 'a completed order shows no payment/complete buttons', implode(',', $labels));
}

echo "\n\033[1m6. Invalid transitions are refused\033[0m\n";
$r = press('payment_verify:' . $oid2, $ADMIN);
check((string)order($pdo, $oid2)['status'] === 'completed', 'a completed order cannot be re-verified');
$oidC = makeOrder($pdo, true, true);
press('order_cancel_confirm:' . $oidC, $ADMIN);
check((string)order($pdo, $oidC)['status'] === 'cancelled', 'cancel confirmation actually cancels');
press('order_delivery:' . $oidC, $ADMIN);
check((int)order($pdo, $oidC)['codes_delivered'] === 0, 'a cancelled order is never delivered');
press('order_complete:' . $oidC, $ADMIN);
check((string)order($pdo, $oidC)['status'] === 'cancelled', 'a cancelled order cannot be completed');

echo "\n\033[1m7. Rejection flow\033[0m\n";
$oidR = makeOrder($pdo, true, true);
press('payment_reject:' . $oidR, $ADMIN);   // first press = confirmation only
check((string)order($pdo, $oidR)['payment_status'] === 'submitted',
    'the first Reject press only asks for confirmation, it does not reject');
$confirmSeen = false;
foreach (array_reverse(mockCalls()) as $c) {
    if ($c['method'] === 'editMessageText' && str_contains((string)($c['body']['text'] ?? ''), 'CONFIRM PAYMENT REJECTION')) {
        $confirmSeen = true; break;
    }
}
check($confirmSeen, 'a confirmation prompt is shown');
press('payment_reject_confirm:' . $oidR, $ADMIN);
$o = order($pdo, $oidR);
check($o['payment_status'] === 'rejected', 'confirming rejects the payment', (string)$o['payment_status']);
check($o['status'] === 'payment_rejected', 'order status reflects the rejection', (string)$o['status']);
check((int)$o['codes_delivered'] === 0, 'a rejected payment never delivers codes');
press('order_delivery:' . $oidR, $ADMIN);
check((int)order($pdo, $oidR)['codes_delivered'] === 0, 'delivery stays blocked after rejection');

echo "\n\033[1m8. Processing\033[0m\n";
$oidP = makeOrder($pdo, false, true);
press('order_processing:' . $oidP, $ADMIN);
check((string)order($pdo, $oidP)['status'] !== 'processing',
    'processing is refused while the payment is unverified');
press('payment_verify:' . $oidP, $ADMIN);
check((string)order($pdo, $oidP)['payment_status'] === 'verified', 'physical order payment verified');
press('order_complete:' . $oidP, $ADMIN);
check((string)order($pdo, $oidP)['status'] === 'completed', 'a physical order completes without code delivery');

echo "\n\033[1m9. Webhook robustness — never a 500\033[0m\n";
$cases = [
    'invalid JSON'        => '{"update_id":',
    'empty body'          => '',
    'JSON scalar'         => '"hello"',
    'no callback/message' => '{"update_id":1}',
    'null callback'       => '{"update_id":2,"callback_query":null}',
    'callback no data'    => '{"update_id":3,"callback_query":{"id":"x","from":{"id":' . $ADMIN . '}}}',
    'garbage data'        => '{"update_id":4,"callback_query":{"id":"x","from":{"id":' . $ADMIN . '},"data":"../../etc/passwd"}}',
    'huge order id'       => '{"update_id":5,"callback_query":{"id":"x","from":{"id":' . $ADMIN . '},"data":"payment_verify:999999999"}}',
    'missing from'        => '{"update_id":6,"callback_query":{"id":"x","data":"payment_verify:1"}}',
];
$clean = true;
foreach ($cases as $label => $body) {
    $r = rawPost($body, ['X-Telegram-Bot-Api-Secret-Token: ' . $SECRET]);
    if ($r['code'] !== 200) { bad("\"$label\" returned HTTP {$r['code']}"); $clean = false; }
    if (preg_match('/Fatal error|Stack trace|SQLSTATE|\/home\//i', $r['body'])) { bad("\"$label\" leaked internals"); $clean = false; }
}
if ($clean) { ok('all ' . count($cases) . ' malformed updates answered 200 with no leakage'); }

$r = rawPost('{"update_id":7,"message":{"text":"/help"}}', ['X-Telegram-Bot-Api-Secret-Token: wrong']);
check($r['code'] === 403, 'a bad secret token is rejected with 403', "got {$r['code']}");

$ch = curl_init($WH);
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15]);
curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
check($code === 200, 'GET returns a safe liveness reply', "got $code");

echo "\n\033[1m10. Duplicate Telegram delivery is ignored\033[0m\n";
$oidD = makeOrder($pdo, true, true);
$dupPayload = json_encode(['update_id' => 987654, 'callback_query' => [
    'id' => 'cbdup', 'from' => ['id' => (int)$ADMIN, 'first_name' => 'Test'],
    'message' => ['message_id' => 1, 'chat' => ['id' => (int)$ADMIN]],
    'data' => 'payment_verify:' . $oidD]]);
rawPost($dupPayload, ['X-Telegram-Bot-Api-Secret-Token: ' . $SECRET]); usleep(500000);
$firstStatus = (string)order($pdo, $oidD)['payment_status'];
$logsBefore = (int)$pdo->query("SELECT COUNT(*) FROM telegram_admin_log WHERE order_id=$oidD")->fetchColumn();
rawPost($dupPayload, ['X-Telegram-Bot-Api-Secret-Token: ' . $SECRET]); usleep(500000);
$logsAfter = (int)$pdo->query("SELECT COUNT(*) FROM telegram_admin_log WHERE order_id=$oidD")->fetchColumn();
check($firstStatus === 'verified', 'the first delivery of the update is processed');
check($logsAfter === $logsBefore, 'a redelivered update_id is ignored entirely', "$logsBefore -> $logsAfter");

echo "\n\033[1m11. Admin commands\033[0m\n";
@unlink($MOCK);
sendCmd('/help', $ADMIN);
$sent = array_filter(mockCalls(), static fn($c) => $c['method'] === 'sendMessage');
check(count($sent) > 0, '/help replies');
@unlink($MOCK);
sendCmd('/help', $STRANGER);
$replies = array_values(array_filter(mockCalls(), static fn($c) => $c['method'] === 'sendMessage'));
$unauth = $replies && str_contains((string)($replies[0]['body']['text'] ?? ''), 'Unauthorized');
check($unauth, 'an unauthorised user gets "Unauthorized access."');
@unlink($MOCK);
sendCmd('/status ' . (string)order($pdo, $oid2)['order_number'], $ADMIN);
$replies = array_values(array_filter(mockCalls(), static fn($c) => $c['method'] === 'sendMessage'));
check($replies && str_contains((string)($replies[0]['body']['text'] ?? ''), 'Completed'),
    '/status reports the real order state');

echo "\n\033[1m12. Secrets never escape\033[0m\n";
$token = '123456789:AAtestBotToken_abcdefghijklmnop';
$leaked = false;
foreach (mockCalls() as $c) {
    if (str_contains(json_encode($c['body']), $token)) { $leaked = true; break; }
}
check(!$leaked, 'the bot token never appears in a Telegram message body');
$logFile = '/home/user/shop/logs/app-' . date('Y-m-d') . '.log';
$log = is_file($logFile) ? (string)file_get_contents($logFile) : '';
check(!str_contains($log, 'AAtestBotToken'), 'the bot token never reaches the log file');
$r = rawPost('{"update_id":8}', ['X-Telegram-Bot-Api-Secret-Token: ' . $SECRET]);
check(!str_contains($r['body'], $token) && !str_contains($r['body'], $SECRET),
    'the webhook response contains no credentials');

// --- restore -------------------------------------------------------------
foreach ($saved as $k => $v) { setting($pdo, $k, $v); }
$pdo->exec("DELETE FROM telegram_updates");

echo "\n" . str_repeat('=', 52) . "\n";
echo "Telegram control panel: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
