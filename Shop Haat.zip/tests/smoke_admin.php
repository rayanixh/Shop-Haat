<?php
declare(strict_types=1);
$BASE='http://127.0.0.1:8080'; $J='/tmp/sm-adm.txt'; @unlink($J);
function req(string $u, string $j, array $post=null): array {
  $ch=curl_init($u);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_COOKIEJAR=>$j,CURLOPT_COOKIEFILE=>$j,
    CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>25]);
  if($post!==null){curl_setopt($ch,CURLOPT_POST,true);curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($post));}
  $b=curl_exec($ch); $c=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  return ['code'=>$c,'body'=>(string)$b];
}
// login
$r=req("$BASE/admin/login.php",$J);
preg_match('/name="csrf_token" value="([^"]+)"/',$r['body'],$m);
$r=req("$BASE/admin/login.php",$J,['csrf_token'=>$m[1],'email'=>'admin@shophaat.test','password'=>'AdminPass123']);
if(stripos($r['body'],'sh-admin-sidebar')===false){echo "LOGIN FAILED\n";exit(1);}
echo "  \033[32mPASS\033[0m  admin login\n";

$pdo=new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4','shopuser','shoppass123');
$pid=$pdo->query('SELECT id FROM products LIMIT 1')->fetchColumn();
$cid=$pdo->query('SELECT id FROM categories LIMIT 1')->fetchColumn();
$mid=$pdo->query('SELECT id FROM payment_methods LIMIT 1')->fetchColumn();
$gid=$pdo->query('SELECT id FROM payment_gateways LIMIT 1')->fetchColumn();

$pages=['dashboard.php','homepage.php','homepage.php?edit=1','homepage.php?new=slider','products.php','products.php?new=1',"products.php?edit=$pid",
 'products.php?status=low&q=a','categories.php',"categories.php?edit=$cid",'brands.php',
 'digital-codes.php','digital-codes.php?status=used','coupons.php','orders.php','orders.php?status=completed',
 'payments.php','payments.php?status=all','customers.php','payment-methods.php',"payment-methods.php?edit=$mid",
 'payment-gateways.php',"payment-gateways.php?edit=$gid",'telegram.php','whatsapp.php','messenger.php',
 'email.php','notifications.php','settings.php','logs.php',
 'orders.php?id=999999','customers.php?id=999999','payments.php?id=999999'];
$pass=0;$fail=0;
foreach($pages as $p){
  $r=req("$BASE/admin/$p",$J);
  $exp404=str_contains($p,'999999');
  $okc=$exp404?in_array($r['code'],[200,404],true):$r['code']===200;
  $leak=!str_contains($p,'logs.php')&&(stripos($r['body'],'Fatal error')!==false||stripos($r['body'],'Uncaught')!==false
    ||preg_match('/\bWarning<\/b>:/i',$r['body'])||stripos($r['body'],'shoppass123')!==false
    ||stripos($r['body'],'Parse error')!==false);
  $shell=str_contains($r['body'],'sh-admin-sidebar');
  if($okc&&!$leak&&$shell){$pass++;echo "  \033[32mPASS\033[0m  $p ({$r['code']})\n";}
  else{$fail++;$why=!$okc?"code {$r['code']}":($leak?'error leaked':'no admin shell');
    echo "  \033[31mFAIL\033[0m  $p — $why\n";
    if($leak&&preg_match('/(Fatal error|Uncaught|Warning|Parse error)[^<\n]{0,180}/i',$r['body'],$mm))echo "        ".trim($mm[0])."\n";}
}
// unauthenticated access must redirect to login
@unlink('/tmp/sm-anon.txt');
$r=req("$BASE/admin/dashboard.php",'/tmp/sm-anon.txt');
if(str_contains($r['body'],'sh-adminlogin')||str_contains($r['body'],'Admin Sign In')){$pass++;echo "  \033[32mPASS\033[0m  guest blocked from dashboard\n";}
else{$fail++;echo "  \033[31mFAIL\033[0m  guest NOT blocked from dashboard\n";}
echo "\nAdmin: \033[32m$pass passed\033[0m, \033[31m$fail failed\033[0m\n";
exit($fail?1:0);
