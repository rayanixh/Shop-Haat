import asyncio, sys
from playwright.async_api import async_playwright
URL, OUT = sys.argv[1], sys.argv[2]
W = int(sys.argv[3]) if len(sys.argv) > 3 else 1440
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': W, 'height': 900})
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('http://127.0.0.1:8080/admin/login.php', wait_until='networkidle')
        await pg.fill('input[name=email]', 'admin@shophaat.test')
        await pg.fill('input[name=password]', 'AdminPass123')
        await pg.click('button[type=submit]')
        await pg.wait_for_load_state('networkidle')
        await pg.goto(URL, wait_until='networkidle')
        ov = await pg.evaluate("()=>({sw:Math.max(document.body.scrollWidth,document.documentElement.clientWidth),cw:document.documentElement.clientWidth})")
        print(f"OVERFLOW sw={ov['sw']} cw={ov['cw']}", "OK" if ov['sw'] <= ov['cw']+1 else "*** OVERFLOW ***")
        if ov['sw'] > ov['cw']+1:
            off = await pg.evaluate("""()=>{const w=document.documentElement.clientWidth;
              // Ignore elements that live inside a horizontal scroll container: that is intentional.
              const inScroller=e=>{let p=e.parentElement;while(p){const o=getComputedStyle(p).overflowX;
                if(o==='auto'||o==='scroll'||o==='hidden')return true;p=p.parentElement;}return false;};
              return [...document.querySelectorAll('*')].filter(e=>e.getBoundingClientRect().right>w+1&&!inScroller(e))
                .slice(0,4).map(e=>e.tagName+'.'+(e.className||'').toString().slice(0,40));}""")
            print("  culprits:", off)
        # detect text clipped inside its own box
        clipped = await pg.evaluate("""()=>[...document.querySelectorAll('.sh-stat__label,.sh-stat__value,.sh-chancard__name,.sh-statuspill')]
            .filter(e=>e.scrollWidth>e.clientWidth+1)
            .slice(0,6).map(e=>(e.className||'')+': '+e.textContent.trim().slice(0,30))""")
        print("CLIPPED:", clipped if clipped else "none")
        print("JS ERRORS:", errs if errs else "clean")
        await pg.screenshot(path=OUT, full_page=True)
        await b.close()
asyncio.run(main())
