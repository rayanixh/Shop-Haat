#!/usr/bin/env bash
# Full verification suite for the ShopHaat storefront.
set -u
cd /home/user
FAILED=0
run() { echo; echo "══════ $1 ══════"; shift; "$@" || FAILED=1; }

echo "══════ Syntax (php -l, every file) ══════"
ERR=0; N=0
while IFS= read -r f; do
  N=$((N+1)); php -l "$f" >/dev/null 2>&1 || { echo "  SYNTAX ERROR: $f"; ERR=1; }
done < <(find /home/user/shop -name '*.php' -not -path '*/logs/*')
[ $ERR -eq 0 ] && echo "  $N files, 0 syntax errors" || FAILED=1

run "Include dependency resolution" php tests/deps.php
run "Storefront pages"              php tests/smoke.php http://127.0.0.1:8080
run "Admin panel"                   php tests/smoke_admin.php
run "Database & installer states"    php tests/dbstates.php
run "End-to-end purchase flow"      php tests/e2e.php
run "Notification delivery"         php tests/notify.php
run "Logo upload & display"         php tests/logos.php
run "Homepage promo manager"        php tests/promo.php
run "Category images"               php tests/category_images.php
run "WhatsApp webhook"              php tests/webhook.php
run "Telegram control panel"        php tests/telegram.php
run "AI Auto Work"                  php tests/ai.php

if python -c "import playwright" 2>/dev/null; then
  run "Responsive — storefront"       python tests/responsive.py
  run "Responsive — admin"            python tests/responsive_admin.py
  run "Homepage promo slider"         python tests/hero.py
  run "Panels are static boxes"       python tests/panels.py
else
  echo; echo "══════ Responsive checks ══════"; echo "  SKIPPED (playwright not installed)"
fi

echo
echo "════════════════════════════════════════"
[ $FAILED -eq 0 ] && echo "ALL SUITES PASSED" || echo "SOME SUITES FAILED"
exit $FAILED
