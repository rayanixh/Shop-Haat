<?php
/**
 * Payment-method / site logo upload and display.
 *
 * The original bug: when the database held a filename whose file was missing from
 * disk, the admin emitted <img src=""> which browsers render as a broken "no image"
 * icon. Every render path must either show a real image or a proper fallback —
 * never an empty src.
 */
declare(strict_types=1);
$B = 'http://127.0.0.1:8080';
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

// --- build a tiny valid PNG on the fly -----------------------------------

/** Ask the running site whether it can serve one of its own uploaded images. */
function sh_uploads_reachable_probe(): array {
    $probe = '/home/user/shop/_probe_uploads.php';
    file_put_contents($probe, "<?php require __DIR__.'/config/config.php';"
        . "header('Content-Type: text/plain'); \$r = sh_uploads_reachable('logos');"
        . "echo (\$r['ok']?'OK':'FAIL'), '|', \$r['status'], '|', \$r['error'] ?? '';");
    $ch = curl_init('http://127.0.0.1:8080/_probe_uploads.php');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20]);
    $out = (string)curl_exec($ch); curl_close($ch);
    @unlink($probe);
    $parts = explode('|', $out, 3);
    // status 0 means "nothing uploaded yet", which is not a failure.
    $ok = ($parts[0] ?? '') === 'OK' || (int)($parts[1] ?? 0) === 0;
    return ['ok' => $ok, 'note' => trim($out)];
}

function makePng(string $path, int $w = 64, int $h = 64): void {
    $chunk = static function (string $t, string $d): string {
        return pack('N', strlen($d)) . $t . $d . pack('N', crc32($t . $d));
    };
    $raw = '';
    for ($y = 0; $y < $h; $y++) { $raw .= "\x00" . str_repeat("\xE6\x50\x1B", $w); }
    $png = "\x89PNG\r\n\x1a\n"
        . $chunk('IHDR', pack('NNCCCCC', $w, $h, 8, 2, 0, 0, 0))
        . $chunk('IDAT', gzcompress($raw))
        . $chunk('IEND', '');
    file_put_contents($path, $png);
}
$tmpPng = '/tmp/logo-test.png';
makePng($tmpPng);

$J = '/tmp/logo-adm.txt'; @unlink($J);
function req(string $url, $post = null, bool $follow = true): string {
    global $J;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J,
        CURLOPT_COOKIEFILE => $J, CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_TIMEOUT => 40]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
    $b = (string)curl_exec($ch); curl_close($ch);
    return $b;
}
function tok(string $html): string {
    return preg_match('/name="csrf_token" value="([^"]+)"/', $html, $m) ? $m[1] : '';
}

$p = req("$B/admin/login.php");
req("$B/admin/login.php", http_build_query(['csrf_token' => tok($p),
    'email' => 'admin@shophaat.test', 'password' => 'AdminPass123']));
$id = (int)$pdo->query("SELECT id FROM payment_methods ORDER BY id LIMIT 1")->fetchColumn();
$name = (string)$pdo->query("SELECT name FROM payment_methods WHERE id=$id")->fetchColumn();
$code = (string)$pdo->query("SELECT code FROM payment_methods WHERE id=$id")->fetchColumn();
$original = $pdo->query("SELECT logo FROM payment_methods WHERE id=$id")->fetchColumn();

function saveWithLogo(string $B, int $id, string $name, string $code, ?string $file): string {
    $form = req("$B/admin/payment-methods.php?edit=$id");
    $fields = ['csrf_token' => tok($form), 'form' => 'save', 'id' => (string)$id,
        'current_logo' => '', 'name' => $name, 'code' => $code, 'type' => 'manual',
        'account_number' => '01700000000', 'extra_charge' => '0', 'sort_order' => '1', 'status' => '1'];
    if ($file !== null) { $fields['logo'] = new CURLFile($file, 'image/png', 'logo.png'); }
    // Return the IMMEDIATE response: validation errors are rendered inline, not after a redirect.
    return req("$B/admin/payment-methods.php?edit=$id", $fields, false);
}

echo "\n\033[1m1. Uploading a logo actually stores and serves it\033[0m\n";
saveWithLogo($B, $id, $name, $code, $tmpPng);
$stored = (string)$pdo->query("SELECT COALESCE(logo,'') FROM payment_methods WHERE id=$id")->fetchColumn();
check($stored !== '', 'a filename was saved to the database', 'got empty');
$disk = '/home/user/shop/uploads/logos/' . $stored;
check($stored !== '' && is_file($disk), 'the file exists on disk', $disk);

$ch = curl_init("$B/uploads/logos/" . rawurlencode($stored));
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20]);
curl_exec($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);
check($httpCode === 200, 'the logo is reachable over HTTP', "code $httpCode");
check(str_contains($ctype, 'image/'), 'it is served with an image content-type', $ctype);

$edit = req("$B/admin/payment-methods.php?edit=$id");
check(str_contains($edit, 'uploads/logos/' . $stored), 'the edit form previews the uploaded logo');
$list = req("$B/admin/payment-methods.php");
check(str_contains($list, 'uploads/logos/' . $stored), 'the admin list shows the logo');

echo "\n\033[1m2. A missing file must NOT produce a blank image\033[0m\n";
$pdo->exec("UPDATE payment_methods SET logo='does-not-exist.png' WHERE id=$id");
$edit = req("$B/admin/payment-methods.php?edit=$id");
check(!str_contains($edit, 'src=""'), 'edit form emits no empty img src');
check((bool)preg_match('/missing from the server/i', strip_tags($edit)), 'edit form explains the file is missing');
$list = req("$B/admin/payment-methods.php");
check(!preg_match('/sh-table__thumb[^>]*src=""/', $list), 'admin list emits no empty img src');
check(str_contains($list, 'sh-icon') || str_contains($list, '<svg'), 'admin list falls back to an icon');

echo "\n\033[1m3. No logo at all is handled cleanly\033[0m\n";
$pdo->exec("UPDATE payment_methods SET logo=NULL WHERE id=$id");
$edit = req("$B/admin/payment-methods.php?edit=$id");
check(!str_contains($edit, 'src=""'), 'edit form emits no empty img src when there is no logo');
$list = req("$B/admin/payment-methods.php");
check(!preg_match('/sh-table__thumb[^>]*src=""/', $list), 'admin list emits no empty img src when there is no logo');

echo "\n\033[1m3b. .htaccess cannot break image serving\033[0m\n";
// An unguarded php_flag/php_value in .htaccess makes Apache return HTTP 500 for
// the whole folder on FastCGI/PHP-FPM hosts, which hides every uploaded image.
foreach (['/home/user/shop/.htaccess', '/home/user/shop/uploads/.htaccess'] as $hta) {
    if (!is_file($hta)) { continue; }
    $depth = 0; $unguarded = [];
    foreach (explode("\n", (string)file_get_contents($hta)) as $n => $line) {
        $t = trim($line);
        if (preg_match('/^<IfModule/i', $t)) { $depth++; }
        elseif (preg_match('#^</IfModule#i', $t)) { $depth--; }
        elseif (preg_match('/^php_(flag|value|admin_flag|admin_value)\b/i', $t) && $depth === 0) {
            $unguarded[] = ($n + 1) . ': ' . $t;
        }
    }
    check(!$unguarded, basename(dirname($hta)) . '/.htaccess has no unguarded php_flag/php_value',
        implode(' | ', $unguarded));
}
$up = sh_uploads_reachable_probe();
check($up['ok'], 'an uploaded image is reachable over HTTP', $up['note']);

echo "\n\033[1m4. Upload directories exist and are writable\033[0m\n";
foreach (['products', 'logos', 'payments'] as $sub) {
    $d = '/home/user/shop/uploads/' . $sub;
    check(is_dir($d) && is_writable($d), "uploads/$sub exists and is writable");
}
check(is_file('/home/user/shop/uploads/.htaccess'), 'uploads/.htaccess guard is present');

echo "\n\033[1m4b. Real images are accepted regardless of filename\033[0m\n";
// Phones often send files with no extension, an uppercase one, or a odd name.
// Only the verified MIME type should matter.
foreach (['noext' => '', 'UPPER.PNG' => '.PNG', 'photo.jpg' => '.jpg (mislabelled png)'] as $fname => $label) {
    $tmp = '/tmp/' . $fname;
    copy($tmpPng, $tmp);
    $resp = saveWithLogo($B, $id, $name, $code, $tmp);
    $got = (string)$pdo->query("SELECT COALESCE(logo,'') FROM payment_methods WHERE id=$id")->fetchColumn();
    check($got !== '' && is_file('/home/user/shop/uploads/logos/' . $got),
        "a valid image named \"$fname\" is accepted", 'stored: ' . $got);
    @unlink($tmp);
}
// Reset so the rejection test below starts from "no logo".
$pdo->exec("UPDATE payment_methods SET logo=NULL WHERE id=$id");

echo "\n\033[1m5. Invalid uploads are rejected with a reason\033[0m\n";
$badFile = '/tmp/not-an-image.png';
file_put_contents($badFile, "<?php echo 'hack'; ?>");
$resp = saveWithLogo($B, $id, $name, $code, $badFile);
$after = (string)$pdo->query("SELECT COALESCE(logo,'') FROM payment_methods WHERE id=$id")->fetchColumn();
check($after === '', 'a disguised PHP file is not accepted as a logo', "stored: $after");
check((bool)preg_match('/not a readable image|Unsupported image type|Only JPG/i', strip_tags($resp)), 'a clear rejection reason is shown');
@unlink($badFile);

// restore
if ($original === null || $original === '') { $pdo->exec("UPDATE payment_methods SET logo=NULL WHERE id=$id"); }
else { $pdo->prepare("UPDATE payment_methods SET logo=? WHERE id=$id")->execute([$original]); }
@unlink($tmpPng);

echo "\n" . str_repeat('=', 52) . "\n";
echo "Logos: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
