<?php
/**
 * AI Auto Work.
 *
 * Drives the real endpoints against a mock OpenAI-compatible server and asserts
 * the DATABASE actually changed. Also covers auth, CSRF, provider failures,
 * duplicate/queue behaviour and secret containment.
 *
 * Requires the mock on 127.0.0.1:9030 (started automatically).
 */
declare(strict_types=1);
$B = 'http://127.0.0.1:8080';
$API = $B . '/api/ai.php';
$MOCK_DIR = '/tmp/aimock';
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED');

/* --- mock provider ---------------------------------------------------- */
if (!is_dir($MOCK_DIR)) { mkdir($MOCK_DIR, 0777, true); }
@unlink($MOCK_DIR . '/mode');
$probe = @file_get_contents('http://127.0.0.1:9030/ping', false,
    stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]));
if ($probe === false) {
    exec('nohup php -S 127.0.0.1:9030 ' . escapeshellarg(__DIR__ . '/mock/openai.php') . ' > /dev/null 2>&1 & echo $!');
    for ($i = 0; $i < 20; $i++) {
        usleep(250000);
        $probe = @file_get_contents('http://127.0.0.1:9030/ping', false,
            stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]));
        if ($probe !== false) { break; }
    }
    if ($probe === false) { echo "  \033[33mSKIP\033[0m  mock provider unavailable\n"; exit(0); }
}
function mockMode(string $m): void { global $MOCK_DIR; file_put_contents($MOCK_DIR . '/mode', $m); }
function mockNormal(): void { global $MOCK_DIR; @unlink($MOCK_DIR . '/mode'); }
function mockCalls(): int {
    global $MOCK_DIR;
    $f = $MOCK_DIR . '/calls.log';
    return is_file($f) ? count(file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES)) : 0;
}

/* --- http helpers ------------------------------------------------------ */
$J = '/tmp/ai-adm.txt'; @unlink($J);
function req(string $url, $post = null, bool $follow = true, ?string $jar = null): string {
    global $J;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar ?? $J,
        CURLOPT_COOKIEFILE => $jar ?? $J, CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_TIMEOUT => 60,
        CURLOPT_HTTPHEADER => ['X-Requested-With: XMLHttpRequest']]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
    $b = (string)curl_exec($ch); curl_close($ch);
    return $b;
}
function status(string $url, $post = null, ?string $jar = null): int {
    global $J;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar ?? $J,
        CURLOPT_COOKIEFILE => $jar ?? $J, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 40]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
    curl_exec($ch);
    $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return $c;
}
function tok(string $html): string {
    if (preg_match('/SH_CSRF = "([^"]+)"/', $html, $m)) { return $m[1]; }
    return preg_match('/name="csrf_token" value="([^"]+)"/', $html, $m2) ? $m2[1] : '';
}
function apiCall(array $fields): array {
    global $API;
    $out = req($API, http_build_query($fields), false);
    $j = json_decode($out, true);
    return is_array($j) ? $j : ['success' => false, 'error' => 'unparseable: ' . substr($out, 0, 120)];
}

/* --- sign in ----------------------------------------------------------- */
$p = req("$B/admin/login.php");
req("$B/admin/login.php", http_build_query(['csrf_token' => tok($p),
    'email' => 'admin@shophaat.test', 'password' => 'AdminPass123']));
$dash = req("$B/admin/ai/index.php");
check(str_contains($dash, 'AI Auto Work'), 'admin can open the AI dashboard');
$CSRF = tok($dash);
check($CSRF !== '', 'a CSRF token is available to the page JS');

/* The DB-states suite reinstalls the store, which drops the AI tables. Make this
   suite self-provisioning so it can run in any order. */
$needInstall = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.tables
    WHERE table_schema=DATABASE() AND table_name='ai_settings'")->fetchColumn() === 0;
if ($needInstall) {
    $sp = req("$B/admin/ai/settings.php");
    req("$B/admin/ai/settings.php", http_build_query(['csrf_token' => tok($sp), 'form' => 'install']));
    $dash = req("$B/admin/ai/index.php");
    $CSRF = tok($dash);
}
/* Point the provider at the mock and store a key the way the settings form does. */
$sp = req("$B/admin/ai/settings.php");
req("$B/admin/ai/settings.php", http_build_query([
    'csrf_token' => tok($sp), 'form' => 'save', 'provider' => 'openai',
    'api_key' => 'sk-test-MOCKKEY-abcdef123456', 'model' => 'gpt-4o-mini',
    'image_model' => 'dall-e-3', 'temperature' => '0.7', 'max_tokens' => '1200',
    'batch_size' => '3', 'max_retries' => '2', 'language' => 'English',
    'tone' => 'Professional', 'seo_mode' => '1', 'api_base' => 'http://127.0.0.1:9030',
]));
$CSRF = tok(req("$B/admin/ai/index.php"));

$pid = (int)$pdo->query('SELECT id FROM products ORDER BY id LIMIT 1')->fetchColumn();
$cid = (int)$pdo->query('SELECT id FROM categories ORDER BY id LIMIT 1')->fetchColumn();

echo "\n\033[1m1. Installation and schema\033[0m\n";
foreach (['ai_settings', 'ai_generations', 'ai_queue', 'ai_prompt_templates', 'blog_posts', 'product_tags'] as $t) {
    $n = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.tables
        WHERE table_schema=DATABASE() AND table_name=" . $pdo->quote($t))->fetchColumn();
    check($n === 1, "table $t exists");
}
foreach (['meta_title', 'meta_description', 'meta_keywords'] as $c) {
    $n = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema=DATABASE() AND table_name='categories' AND column_name=" . $pdo->quote($c))->fetchColumn();
    check($n === 1, "categories.$c added");
}
$dupes = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.columns
    WHERE table_schema=DATABASE() AND table_name='products' AND column_name='meta_title'")->fetchColumn();
check($dupes === 1, 'products.meta_title was reused, not duplicated');
check((int)$pdo->query('SELECT COUNT(*) FROM ai_prompt_templates')->fetchColumn() >= 8,
    'prompt templates were seeded');

echo "\n\033[1m2. Security\033[0m\n";
$anon = '/tmp/ai-anon.txt'; @unlink($anon);
$code = status($API, http_build_query(['action' => 'generate', 'task' => 'title', 'ref_id' => $pid]), $anon);
check($code === 401 || $code === 403 || $code === 302,
    'an unauthenticated request cannot reach the AI endpoint', "got $code");
$before = (string)$pdo->query("SELECT name FROM products WHERE id=$pid")->fetchColumn();

$r = apiCall(['action' => 'generate', 'task' => 'title', 'ref_id' => $pid]); // no CSRF
check(empty($r['success']), 'a request without a CSRF token is rejected');
check((string)$pdo->query("SELECT name FROM products WHERE id=$pid")->fetchColumn() === $before,
    'the rejected request changed nothing');

$r = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'evil; DROP TABLE products', 'ref_id' => $pid]);
check(empty($r['success']), 'an unknown task is refused');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'nope']);
check(empty($r['success']), 'an unknown action is refused');

$KEY = 'sk-test-MOCKKEY-abcdef123456';
$rawKey = (int)$pdo->query('SELECT COUNT(*) FROM ai_settings WHERE setting_value LIKE ' . $pdo->quote('%MOCKKEY%'))->fetchColumn();
check($rawKey === 0, 'the API key is encrypted at rest, never plain text');
foreach (["$B/admin/ai/settings.php", "$B/admin/ai/index.php", "$B/assets/js/app.js", "$B/"] as $u) {
    if (str_contains(req($u), $KEY)) { bad("the API key leaked from $u"); }
}
ok('the API key appears in no page or asset');

echo "\n\033[1m3. Real generation writes real data\033[0m\n";
$callsBefore = mockCalls();
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'title', 'ref_id' => $pid]);
check(!empty($r['success']), 'title generation succeeds', (string)($r['error'] ?? ''));
check(mockCalls() > $callsBefore, 'a real HTTP request reached the provider');
check(!empty($r['data']['title']), 'a title came back');
check((string)$pdo->query("SELECT name FROM products WHERE id=$pid")->fetchColumn() === $before,
    'generation alone does NOT modify the product');

$title = (string)$r['data']['title'];
$r2 = apiCall(['csrf_token' => $CSRF, 'action' => 'save', 'task' => 'title', 'ref_id' => $pid,
               'data' => json_encode($r['data'])]);
check(!empty($r2['success']), 'saving succeeds');
check((string)$pdo->query("SELECT name FROM products WHERE id=$pid")->fetchColumn() === $title,
    'the product row really changed');

foreach ([
    'description' => ['description', 'description'],
    'short'       => ['short_description', 'short_description'],
] as $task => [$field, $col]) {
    $g = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => $task, 'ref_id' => $pid]);
    if (empty($g['success'])) { bad("$task generation", (string)($g['error'] ?? '')); continue; }
    apiCall(['csrf_token' => $CSRF, 'action' => 'save', 'task' => $task, 'ref_id' => $pid,
             'data' => json_encode($g['data'])]);
    $val = (string)$pdo->query("SELECT COALESCE($col,'') FROM products WHERE id=$pid")->fetchColumn();
    check(trim($val) !== '', "$task saved into products.$col");
}

$g = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'tags', 'ref_id' => $pid]);
check(!empty($g['success']) && !empty($g['data']['tags']), 'tag generation returns a list');
apiCall(['csrf_token' => $CSRF, 'action' => 'save', 'task' => 'tags', 'ref_id' => $pid,
         'data' => json_encode($g['data'])]);
$tagCount = (int)$pdo->query("SELECT COUNT(*) FROM product_tags WHERE product_id=$pid")->fetchColumn();
check($tagCount > 0, "tags saved to product_tags ($tagCount)");
// Re-saving must not create duplicates.
apiCall(['csrf_token' => $CSRF, 'action' => 'save', 'task' => 'tags', 'ref_id' => $pid,
         'data' => json_encode($g['data'])]);
check((int)$pdo->query("SELECT COUNT(*) FROM product_tags WHERE product_id=$pid")->fetchColumn() === $tagCount,
    'saving the same tags again creates no duplicates');

$g = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'seo', 'ref_id' => $pid]);
check(!empty($g['success']) && !empty($g['data']['meta_title']), 'SEO generation returns metadata');
apiCall(['csrf_token' => $CSRF, 'action' => 'save', 'task' => 'seo', 'ref_id' => $pid,
         'data' => json_encode($g['data'])]);
$row = $pdo->query("SELECT meta_title, meta_keywords FROM products WHERE id=$pid")->fetch(PDO::FETCH_ASSOC);
check(trim((string)$row['meta_title']) !== '', 'SEO saved into the EXISTING products.meta_title');
check(trim((string)$row['meta_keywords']) !== '', 'keywords saved into products.meta_keywords');

echo "\n\033[1m4. Category suggestion never duplicates a category\033[0m\n";
$catsBefore = (int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
$g = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'category', 'ref_id' => $pid]);
check(!empty($g['success']), 'category suggestion succeeds', (string)($g['error'] ?? ''));
check(isset($g['data']['exists']), 'the response says whether the category already exists');
check((int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn() === $catsBefore,
    'suggesting a category creates nothing on its own');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'create_category',
              'name' => (string)$g['data']['suggested'], 'ref_id' => $pid]);
check(!empty($r['success']), 'create_category succeeds');
check((int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn() === $catsBefore,
    'an existing category is reused rather than duplicated');

echo "\n\033[1m5. Category and blog content\033[0m\n";
$g = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'category_content', 'ref_id' => $cid]);
check(!empty($g['success']), 'category content generated', (string)($g['error'] ?? ''));
apiCall(['csrf_token' => $CSRF, 'action' => 'save', 'task' => 'category_content', 'ref_id' => $cid,
         'data' => json_encode($g['data'])]);
$c = $pdo->query("SELECT description, meta_title FROM categories WHERE id=$cid")->fetch(PDO::FETCH_ASSOC);
check(trim((string)$c['description']) !== '' && trim((string)$c['meta_title']) !== '',
    'category description and SEO saved');

$postsBefore = (int)$pdo->query('SELECT COUNT(*) FROM blog_posts')->fetchColumn();
$g = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'blog', 'ref_id' => 0,
              'topic' => 'Best summer fashion', 'keywords' => 'summer, cotton', 'length' => '600']);
check(!empty($g['success']) && !empty($g['data']['title']), 'blog generation returns a post');
check((int)$pdo->query('SELECT COUNT(*) FROM blog_posts')->fetchColumn() === $postsBefore,
    'generating a post saves nothing yet');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'save_blog', 'data' => json_encode($g['data']), 'publish' => '1']);
check(!empty($r['success']), 'blog save succeeds');
check(($r['status'] ?? '') === 'draft',
    'publish is refused while auto-publish is OFF — saved as draft', (string)($r['status'] ?? ''));
$saved = $pdo->query('SELECT status, source FROM blog_posts ORDER BY id DESC LIMIT 1')->fetch(PDO::FETCH_ASSOC);
check(($saved['status'] ?? '') === 'draft' && ($saved['source'] ?? '') === 'ai', 'the row is a draft flagged as AI');

echo "\n\033[1m6. Image generation\033[0m\n";
$g = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'image', 'ref_id' => $pid]);
check(!empty($g['success']), 'image generation succeeds', (string)($g['error'] ?? ''));
$file = (string)($g['data']['file'] ?? '');
check($file !== '' && is_file('/home/user/shop/uploads/products/' . $file),
    'the image is written into the EXISTING product upload folder', $file);
$imgBefore = (string)$pdo->query("SELECT COALESCE(image,'') FROM products WHERE id=$pid")->fetchColumn();
check($imgBefore !== $file, 'the product image is NOT replaced without confirmation');
apiCall(['csrf_token' => $CSRF, 'action' => 'save', 'task' => 'image', 'ref_id' => $pid,
         'data' => json_encode($g['data'])]);
check((string)$pdo->query("SELECT image FROM products WHERE id=$pid")->fetchColumn() === $file,
    'confirming attaches the image to the product');

echo "\n\033[1m7. Bulk queue processes in batches\033[0m\n";
$ids = array_column($pdo->query('SELECT id FROM products ORDER BY id LIMIT 4')->fetchAll(PDO::FETCH_ASSOC), 'id');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'bulk_queue',
              'products' => implode(',', $ids), 'tasks' => 'short,seo']);
check(!empty($r['success']), 'a batch can be queued', (string)($r['error'] ?? ''));
$batch = (string)($r['batch_id'] ?? '');
check((int)($r['total'] ?? 0) === count($ids) * 2, 'the job count is products x tasks');
$queued = (int)$pdo->query('SELECT COUNT(*) FROM ai_queue WHERE batch_id=' . $pdo->quote($batch))->fetchColumn();
check($queued === count($ids) * 2, 'jobs are persisted as pending');

$guard = 0;
do {
    $p = apiCall(['csrf_token' => $CSRF, 'action' => 'bulk_process', 'batch_id' => $batch]);
    $guard++;
} while (empty($p['finished']) && $guard < 30);
check(!empty($p['finished']), 'the batch runs to completion');
check((int)($p['completed'] ?? 0) === $queued, 'every job completed', json_encode($p));
$applied = (int)$pdo->query('SELECT COUNT(*) FROM products WHERE id IN (' . implode(',', $ids) . ")
    AND COALESCE(meta_title,'') <> ''")->fetchColumn();
check($applied === count($ids), 'bulk results were written to every product', "$applied/" . count($ids));

$over = apiCall(['csrf_token' => $CSRF, 'action' => 'bulk_queue',
                 'products' => implode(',', range(1, 60)), 'tasks' => 'title,description,short,seo']);
check(empty($over['success']), 'an oversized batch is refused (cost control)');

echo "\n\033[1m8. Provider failures are honest\033[0m\n";
mockMode('401');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'title', 'ref_id' => $pid]);
check(empty($r['success']), 'a 401 from the provider is reported as a failure');
check(str_contains((string)$r['error'], 'API key'), 'the message points at the API key', (string)$r['error']);

mockMode('429');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'title', 'ref_id' => $pid]);
check(empty($r['success']) && str_contains((string)$r['error'], 'Rate limit'), 'a 429 is surfaced clearly');

mockMode('500');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'title', 'ref_id' => $pid]);
check(empty($r['success']), 'a provider 500 does not crash the endpoint');

mockMode('garbage');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'title', 'ref_id' => $pid]);
check(empty($r['success']), 'an unreadable provider response is handled');

mockMode('empty');
$r = apiCall(['csrf_token' => $CSRF, 'action' => 'generate', 'task' => 'title', 'ref_id' => $pid]);
check(empty($r['success']), 'an empty completion is treated as a failure, not a save');

$failLogged = (int)$pdo->query("SELECT COUNT(*) FROM ai_generations WHERE status='failed'")->fetchColumn();
check($failLogged >= 4, "failures are recorded in history ($failLogged)");
$leak = (int)$pdo->query('SELECT COUNT(*) FROM ai_generations WHERE response LIKE ' . $pdo->quote('%MOCKKEY%')
    . ' OR prompt LIKE ' . $pdo->quote('%MOCKKEY%'))->fetchColumn();
check($leak === 0, 'no API key is stored in the generation log');
mockNormal();

echo "\n\033[1m9. Admin pages all render\033[0m\n";
foreach (['index.php', 'products.php', 'bulk.php', 'blog.php', 'category.php',
          'seo.php', 'image.php', 'history.php', 'settings.php'] as $page) {
    $html = req("$B/admin/ai/$page");
    $bad = preg_match('/Fatal error|Stack trace|SQLSTATE|Warning<\/b>/i', $html);
    check(!$bad && str_contains($html, 'sh-admin-sidebar'), "admin/ai/$page renders cleanly");
}
$html = req("$B/admin/ai/products.php?id=$pid");
check(str_contains($html, 'data-ai-generate="title"'), 'Product AI exposes working generate buttons');
$html = req("$B/admin/ai/history.php");
check(str_contains($html, 'Generations'), 'AI History lists generations');

echo "\n\033[1m10. Existing site is unaffected\033[0m\n";
check(status("$B/") === 200, 'the storefront still loads');
check(status("$B/admin/products.php") === 200, 'the existing products admin still loads');
check(status("$B/admin/dashboard.php") === 200, 'the admin dashboard still loads');

echo "\n" . str_repeat('=', 52) . "\n";
echo "AI Auto Work: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
