<?php
/**
 * Proves the notification pipeline really delivers.
 *
 * Points the Telegram driver at a local mock provider, then checks that:
 *   - the admin "Send test message" endpoint actually performs an HTTP call
 *   - the bot token is sent UNENCODED (the colon must survive)
 *   - a real purchase fires every lifecycle event
 *   - unconfigured channels are skipped, never reported as sent
 *   - a failing channel never breaks the order
 *
 * Requires the mock provider on 127.0.0.1:9010 (started by this script's caller
 * or automatically below).
 */
declare(strict_types=1);
$B = 'http://127.0.0.1:8080';
$MOCK_LOG = '/tmp/mockapi/received.log';
if (!is_dir('/tmp/mockapi')) { mkdir('/tmp/mockapi', 0777, true); }
$pass = 0; $fail = 0;
function ok(string $m): void { global $pass; $pass++; echo "  \033[32mPASS\033[0m  $m\n"; }
function bad(string $m, string $d = ''): void { global $fail; $fail++; echo "  \033[31mFAIL\033[0m  $m" . ($d ? " — $d" : '') . "\n"; }
function check(bool $c, string $m, string $d = ''): void { $c ? ok($m) : bad($m, $d); }

$pdo = new PDO('mysql:host=127.0.0.1;dbname=shopdb;charset=utf8mb4', 'shopuser', 'shoppass123',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
function setting(PDO $p, string $k, string $v): void {
    $p->prepare('INSERT INTO settings (setting_key,setting_value) VALUES (?,?)
                 ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)')->execute([$k, $v]);
}

// --- mock provider must be reachable -------------------------------------
// Start the bundled mock provider if it is not already running, so this suite is self-contained.
$probe = @file_get_contents('http://127.0.0.1:9010/ping', false,
    stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]));
if ($probe === false) {
    $mock = __DIR__ . '/mock/telegram.php';
    exec('nohup php -S 127.0.0.1:9010 ' . escapeshellarg($mock) . ' > /dev/null 2>&1 & echo $!');
    for ($i = 0; $i < 20; $i++) {
        usleep(250000);
        $probe = @file_get_contents('http://127.0.0.1:9010/ping', false,
            stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]));
        if ($probe !== false) { break; }
    }
    if ($probe === false) {
        echo "  \033[33mSKIP\033[0m  could not start the mock provider on 127.0.0.1:9010\n";
        exit(0);
    }
}

$TOKEN = '123456789:AAExample_Token-abcDEF';
$saved = [];
foreach (['telegram_enabled', 'telegram_bot_token', 'telegram_chat_id', 'telegram_api_base'] as $k) {
    $st = $pdo->prepare('SELECT setting_value FROM settings WHERE setting_key=?');
    $st->execute([$k]);
    $saved[$k] = (string)($st->fetchColumn() ?: '');
}

function login(string $B): string {
    $J = '/tmp/notif-adm.txt'; @unlink($J);
    $ch = curl_init("$B/admin/login.php");
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J, CURLOPT_COOKIEFILE => $J, CURLOPT_TIMEOUT => 25]);
    $p = (string)curl_exec($ch); curl_close($ch);
    preg_match('/name="csrf_token" value="([^"]+)"/', $p, $m);
    $ch = curl_init("$B/admin/login.php");
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J, CURLOPT_COOKIEFILE => $J,
        CURLOPT_TIMEOUT => 25, CURLOPT_FOLLOWLOCATION => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query(['csrf_token' => $m[1] ?? '',
            'email' => 'admin@shophaat.test', 'password' => 'AdminPass123'])]);
    curl_exec($ch); curl_close($ch);
    return $J;
}
function adminToken(string $B, string $J, string $page): string {
    $ch = curl_init("$B/admin/$page");
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J, CURLOPT_COOKIEFILE => $J, CURLOPT_TIMEOUT => 25]);
    $p = (string)curl_exec($ch); curl_close($ch);
    return preg_match('/name="csrf_token" value="([^"]+)"/', $p, $m) ? $m[1] : '';
}
function sendTest(string $B, string $J, string $tok, string $channel): array {
    $ch = curl_init("$B/api/notifications.php");
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $J, CURLOPT_COOKIEFILE => $J,
        CURLOPT_TIMEOUT => 30, CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['X-Requested-With: XMLHttpRequest'],
        CURLOPT_POSTFIELDS => http_build_query(['csrf_token' => $tok, 'channel' => $channel])]);
    $b = (string)curl_exec($ch); curl_close($ch);
    return json_decode($b, true) ?? ['success' => false, 'error' => 'unparseable: ' . substr($b, 0, 80)];
}

echo "\n\033[1m1. The admin test button reaches the provider\033[0m\n";
setting($pdo, 'telegram_enabled', '1');
setting($pdo, 'telegram_bot_token', $TOKEN);
setting($pdo, 'telegram_chat_id', '-1001234567890');
setting($pdo, 'telegram_api_base', 'http://127.0.0.1:9010');
@unlink($MOCK_LOG);

$J = login($B);
$tok = adminToken($B, $J, 'telegram.php');
check($tok !== '', 'admin signed in and CSRF token obtained');

$res = sendTest($B, $J, $tok, 'telegram');
check(!empty($res['success']), 'test endpoint reports success', $res['error'] ?? '');
$log = is_file($MOCK_LOG) ? (string)file_get_contents($MOCK_LOG) : '';
check($log !== '', 'an actual HTTP request reached the provider');
check(str_contains($log, '/bot' . $TOKEN . '/sendMessage'),
    'bot token is sent UNENCODED (colon preserved)', 'log: ' . substr($log, 0, 120));
check(!str_contains($log, '%3A'), 'token is not URL-encoded');
check(str_contains($log, 'TEST NOTIFICATION'), 'the message body was transmitted');

$row = $pdo->query("SELECT status FROM notification_logs WHERE channel='telegram' AND event='test' ORDER BY id DESC LIMIT 1")->fetchColumn();
check($row === 'sent', 'the successful test is logged as sent', 'got ' . var_export($row, true));

echo "\n\033[1m2. A real purchase fires the whole lifecycle\033[0m\n";
@unlink($MOCK_LOG);
$pdo->exec('DELETE FROM notification_logs');
exec('php ' . escapeshellarg('/home/user/tests/e2e.php') . ' 2>&1', $out, $rc);
$log = is_file($MOCK_LOG) ? (string)file_get_contents($MOCK_LOG) : '';
foreach (['NEW ORDER' => 'order placed', 'PAYMENT SUBMITTED' => 'payment submitted',
          'PAYMENT APPROVED' => 'payment approved', 'DIGITAL CODE' => 'digital code delivered'] as $needle => $label) {
    check(str_contains($log, $needle), "provider received the \"$label\" message");
}
$sent = (int)$pdo->query("SELECT COUNT(*) FROM notification_logs WHERE channel='telegram' AND status='sent'")->fetchColumn();
check($sent >= 4, "telegram deliveries logged as sent ($sent)");

echo "\n\033[1m3. Unconfigured channels stay honest\033[0m\n";
$sentOther = (int)$pdo->query("SELECT COUNT(*) FROM notification_logs WHERE channel IN ('whatsapp','messenger') AND status='sent'")->fetchColumn();
check($sentOther === 0, 'unconfigured channels are NEVER logged as sent');
$skipped = (int)$pdo->query("SELECT COUNT(*) FROM notification_logs WHERE status='skipped'")->fetchColumn();
check($skipped > 0, "unconfigured channels are logged as skipped ($skipped)");
$orders = (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
check($orders > 0, 'orders still completed while channels were failing/skipped');
$leak = (int)$pdo->query("SELECT COUNT(*) FROM notification_logs WHERE error_message LIKE '%" . substr($TOKEN, 0, 12) . "%'")->fetchColumn();
check($leak === 0, 'the bot token never appears in the notification log');

echo "\n\033[1m4. A provider outage must not break checkout\033[0m\n";
setting($pdo, 'telegram_api_base', 'http://127.0.0.1:9099'); // nothing listening
$pdo->exec('DELETE FROM notification_logs');
$tok = adminToken($B, $J, 'telegram.php');
$res = sendTest($B, $J, $tok, 'telegram');
check(empty($res['success']), 'a dead provider is reported as failure, not success');
$row = $pdo->query("SELECT status FROM notification_logs WHERE channel='telegram' ORDER BY id DESC LIMIT 1")->fetchColumn();
check($row === 'failed', 'the failure is logged as failed', 'got ' . var_export($row, true));

// restore original settings
foreach ($saved as $k => $v) {
    if ($v === '') { $pdo->prepare('DELETE FROM settings WHERE setting_key=?')->execute([$k]); }
    else { setting($pdo, $k, $v); }
}
$pdo->exec("UPDATE settings SET setting_value='0' WHERE setting_key='telegram_enabled'");

echo "\n" . str_repeat('=', 52) . "\n";
echo "Notifications: \033[32m$pass passed\033[0m, " . ($fail ? "\033[31m$fail failed\033[0m" : '0 failed') . "\n";
exit($fail ? 1 : 0);
