<?php
$raw=file_get_contents('php://input'); $uri=$_SERVER['REQUEST_URI']??'';
file_put_contents('/tmp/meta/recv.log', date('H:i:s')." URI=$uri BODY=$raw\n", FILE_APPEND);
header('Content-Type: application/json');
if (strpos($uri,'/me/messages')!==false) { echo json_encode(['message_id'=>'m_1','recipient_id'=>'123']); exit; }
echo json_encode(['messaging_product'=>'whatsapp','messages'=>[['id'=>'wamid.TEST']]]);
