<?php
// Mock Telegram Bot API for tests. Records calls; replies like the real API.
$dir = '/tmp/tgmock';
if (!is_dir($dir)) { mkdir($dir, 0777, true); }
$uri = $_SERVER['REQUEST_URI'] ?? '';
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== '') {
    $j = json_decode($raw, true);
    $body = is_array($j) ? $j : [];
    if (!$body) { parse_str($raw, $body); }
}
$method = 'unknown';
if (preg_match('#/bot[^/]+/([A-Za-z]+)#', $uri, $m)) { $method = $m[1]; }
file_put_contents($dir . '/calls.log',
    json_encode(['method' => $method, 'uri' => $uri, 'body' => $body]) . "\n", FILE_APPEND);
header('Content-Type: application/json');
$counter = (int)@file_get_contents($dir . '/counter') + 1;
file_put_contents($dir . '/counter', (string)$counter);
switch ($method) {
    case 'sendMessage':
        echo json_encode(['ok' => true, 'result' => ['message_id' => 1000 + $counter,
            'chat' => ['id' => $body['chat_id'] ?? '0'], 'text' => $body['text'] ?? '']]);
        return;
    case 'editMessageText':
    case 'editMessageReplyMarkup':
        echo json_encode(['ok' => true, 'result' => ['message_id' => $body['message_id'] ?? 0]]);
        return;
    case 'answerCallbackQuery':
    case 'setWebhook':
    case 'deleteWebhook':
        echo json_encode(['ok' => true, 'result' => true]);
        return;
    case 'getWebhookInfo':
        echo json_encode(['ok' => true, 'result' => ['url' => 'https://example.test/telegram-webhook.php',
            'pending_update_count' => 0]]);
        return;
}
echo json_encode(['ok' => false, 'description' => 'Unknown method ' . $method]);
