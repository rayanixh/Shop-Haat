<?php
// Mock Telegram API used by tests/notify.php. Records requests, replies like the real API.
$dir = '/tmp/mockapi';
if (!is_dir($dir)) { mkdir($dir, 0777, true); }
$raw = file_get_contents('php://input');
$uri = $_SERVER['REQUEST_URI'] ?? '';
file_put_contents($dir . '/received.log', date('H:i:s') . " URI={$uri} BODY={$raw}\n", FILE_APPEND);
header('Content-Type: application/json');
if (strpos($uri, '%3A') !== false) {   // an encoded colon = the bug this guards against
    http_response_code(404);
    echo json_encode(['ok' => false, 'error_code' => 404, 'description' => 'Not Found']);
    exit;
}
echo json_encode(['ok' => true, 'result' => ['message_id' => 42]]);
