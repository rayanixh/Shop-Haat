<?php
// Mock OpenAI-compatible API. Records calls and returns realistic shapes so the
// whole pipeline (HTTP -> parse -> validate -> save) can be proven end to end.
$dir = '/tmp/aimock';
if (!is_dir($dir)) { mkdir($dir, 0777, true); }
$uri = $_SERVER['REQUEST_URI'] ?? '';
$raw = file_get_contents('php://input');
$body = json_decode($raw, true) ?: [];
$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
file_put_contents($dir . '/calls.log', json_encode(['uri' => $uri, 'auth' => $auth, 'body' => $body]) . "\n", FILE_APPEND);

header('Content-Type: application/json');

// Simulate provider-side failures on demand.
$mode = trim((string)@file_get_contents($dir . '/mode'));
if ($mode === '401') { http_response_code(401); echo json_encode(['error' => ['message' => 'Incorrect API key provided.']]); exit; }
if ($mode === '429') { http_response_code(429); echo json_encode(['error' => ['message' => 'Rate limit reached.']]); exit; }
if ($mode === '500') { http_response_code(500); echo json_encode(['error' => ['message' => 'server_error']]); exit; }
if ($mode === 'garbage') { echo 'not json at all'; exit; }
if ($mode === 'empty') { echo json_encode(['choices' => [['message' => ['content' => '']]]]); exit; }

if (str_contains($uri, '/images/generations')) {
    // 2x2 red PNG
    $png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGP8z4AATAxIHDgLTQIEAAD//wMNAQGwZ2+9AAAAAElFTkSuQmCC');
    echo json_encode(['created' => time(), 'data' => [['b64_json' => base64_encode($png)]]]);
    exit;
}

$messages = $body['messages'] ?? [];
$user = '';
foreach ($messages as $m) { if (($m['role'] ?? '') === 'user') { $user = (string)($m['content'] ?? ''); } }
$system = '';
foreach ($messages as $m) { if (($m['role'] ?? '') === 'system') { $system = (string)($m['content'] ?? ''); } }

// Answer in the shape the prompt asks for.
if (str_contains($system, 'JSON array')) {
    $content = json_encode(['cotton shirt', 'mens fashion', 'casual wear', 'premium shirt', 'summer top']);
} elseif (str_contains($system, '"category"')) {
    $content = json_encode(['category' => 'Electronics', 'confidence' => 88, 'reason' => 'Matches consumer electronics.']);
} elseif (str_contains($system, '"meta_title"') && str_contains($system, '"description"')) {
    $content = json_encode(['description' => 'Explore our curated selection of quality products at honest prices.',
        'meta_title' => 'Shop Quality Products Online', 'meta_description' => 'Browse our range with fast delivery.',
        'keywords' => ['shop', 'online', 'quality']]);
} elseif (str_contains($system, '"title"') && str_contains($system, '"content"')) {
    $content = json_encode(['title' => 'Best Summer Fashion Picks',
        'excerpt' => 'A short guide to summer styles.',
        'content' => '<h2>Intro</h2><p>Summer is here.</p><h2>Picks</h2><ul><li>Cotton shirts</li></ul><h2>Conclusion</h2><p>Stay cool.</p>',
        'meta_title' => 'Best Summer Fashion Picks', 'meta_description' => 'Our guide to summer fashion.',
        'keywords' => ['summer fashion', 'cotton shirt']]);
} elseif (str_contains($system, '"meta_title"')) {
    $content = json_encode(['meta_title' => 'Premium Wireless Headphones | ShopHaat',
        'meta_description' => 'Enjoy rich sound with long battery life. Fast delivery across Bangladesh.',
        'focus_keyword' => 'wireless headphones', 'keywords' => ['wireless headphones', 'bluetooth audio']]);
} elseif (str_contains($system, 'clean HTML')) {
    $content = '<p>This is a generated product description.</p><ul><li>Great sound</li><li>Long battery</li></ul><p>Order today.</p>';
} elseif (str_contains($system, 'image prompt')) {
    $content = 'Professional ecommerce product photo, studio lighting, white background, centred composition.';
} elseif (str_contains($user, 'single word')) {
    $content = 'ready';
} else {
    $content = 'Premium Wireless Headphones with Deep Bass';
}

echo json_encode([
    'id' => 'chatcmpl-mock', 'object' => 'chat.completion', 'model' => $body['model'] ?? 'gpt-4o-mini',
    'choices' => [['index' => 0, 'message' => ['role' => 'assistant', 'content' => $content], 'finish_reason' => 'stop']],
    'usage' => ['prompt_tokens' => 120, 'completion_tokens' => 80, 'total_tokens' => 200],
]);
